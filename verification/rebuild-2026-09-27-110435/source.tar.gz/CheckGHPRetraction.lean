import PaperN.PartI.GHPRetraction

#print PaperN.PartI.GHPRetractionStatement
#check @PaperN.PartI.selectedGHSection_class
#check @PaperN.PartI.continuous_selectedGHSection
#check @PaperN.PartI.ghpRetraction_spec
#print axioms PaperN.PartI.ghRepresentative_class
#print axioms PaperN.PartI.selectedGHSection_class
#print axioms PaperN.PartI.forget_selectedGHSection
#print axioms PaperN.PartI.selectedGHSection_invariant
#print axioms PaperN.PartI.continuous_selectedGHSection
#print axioms PaperN.PartI.exists_range_retraction
#print axioms PaperN.PartI.exists_subspace_range_retraction
#print axioms PaperN.PartI.ghpRetraction_of_selection
#print axioms PaperN.PartI.ghpRetraction_spec
#print axioms PaperN.PartI.sectionRangeHomeomorph
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
