import PaperN.PartI.SelectedProbability

#print PaperN.PartI.NaturalInvariantAssignmentStatement
#check @PaperN.PartI.fiberProbability_unique
#check @PaperN.PartI.continuous_fiberProbability
#check @PaperN.PartI.fiberLawAverage_natural
#check @PaperN.PartI.selectedProbability_withProbability
#check @PaperN.PartI.naturalInvariantAssignment_spec
#print axioms PaperN.PartI.probability_eq_of_invariant_class_eq
#print axioms PaperN.PartI.probability_map_class
#print axioms PaperN.PartI.exists_fiberProbability
#print axioms PaperN.PartI.fiberProbability_fullSupport_invariant
#print axioms PaperN.PartI.fiberProbability_class
#print axioms PaperN.PartI.fiberProbability_unique
#print axioms PaperN.PartI.fiberProbability_eq_map
#print axioms PaperN.PartI.fiberProbability_natural
#print axioms PaperN.PartI.ghpDist_withProbability_le
#print axioms PaperN.PartI.continuous_probabilityClass
#print axioms PaperN.PartI.isEmbedding_invariantProbabilityClass
#print axioms PaperN.PartI.continuous_fiberProbability
#print axioms PaperN.PartI.map_probabilityOnSubtype
#print axioms PaperN.PartI.barycenter_map
#print axioms PaperN.PartI.isClosed_invariantFiber
#print axioms PaperN.PartI.transportedFiberLaw_fullMass
#print axioms PaperN.PartI.fiberLawAverage_fullSupport_invariant
#print axioms PaperN.PartI.continuous_fiberLawAverage
#print axioms PaperN.PartI.integral_fiberLawAverage
#print axioms PaperN.PartI.averageConcentratedLaw_fullSupport_invariant
#print axioms PaperN.PartI.fiberLawAverage_natural
#print axioms PaperN.PartI.averageConcentratedLaw_natural
#print axioms PaperN.PartI.selectedProbability_fullSupport_invariant
#print axioms PaperN.PartI.selectedProbability_natural
#print axioms PaperN.PartI.selectedProbability_withProbability
#print axioms PaperN.PartI.naturalInvariantAssignment_spec
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
