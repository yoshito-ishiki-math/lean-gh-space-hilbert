import PaperN.PartI.MeasuredProjection
import PaperN.PartI.CommonAmbient

#print PaperN.PartI.MeasuredCompact
#print PaperN.PartI.MeasuredCompact.Isomorphic
#print PaperN.PartI.CompactCoupling
#print PaperN.PartI.CompactCoupling.cost
#print PaperN.PartI.ghpEDist
#print PaperN.PartI.GHPBasicStatement
#print PaperN.PartI.GHProjectionBoundStatement
#print PaperN.PartI.InvariantProjectionSurjectivityStatement
#print PaperN.PartI.WeakProkhorovStatement
#check @PaperN.PartI.ghpBasic_spec
#check @PaperN.PartI.ghProjectionBound_spec
#check @PaperN.PartI.invariantProjectionSurjectivity_spec
#check @PaperN.PartI.weakProkhorov_spec
#print axioms PaperN.PartI.ghpBasic_spec
#print axioms PaperN.PartI.ghProjectionBound_spec
#print axioms PaperN.PartI.invariantProjectionSurjectivity_spec
#print axioms PaperN.PartI.weakProkhorov_spec
#print axioms PaperN.PartI.MeasuredCompact.measuredSetoid
#print axioms PaperN.PartI.MeasuredCompact.invariantFullSupport_iff
#print axioms PaperN.PartI.MeasuredGHSpace.edistance
#print axioms PaperN.PartI.MeasuredGHSpace.forget_distance_le
#print axioms PaperN.PartI.invariant_projection_surjective
