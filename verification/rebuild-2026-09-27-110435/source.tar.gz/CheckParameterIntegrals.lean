import PaperN.PartI.ParameterIntegrals

#print PaperN.PartI.UniformWeakIntegralsStatement
#print PaperN.PartI.ParameterIntegralsStatement
#check (PaperN.PartI.uniformWeakIntegrals_spec (Z := Unit) (𝕜 := ℝ))
#check (PaperN.PartI.uniformWeakIntegrals_spec (Z := Unit) (𝕜 := ℂ))
#check (PaperN.PartI.parameterIntegrals_spec (Z := Unit) (P := Unit) (𝕜 := ℝ))
#check (PaperN.PartI.parameterIntegrals_spec (Z := Unit) (P := Unit) (𝕜 := ℂ))
#print axioms PaperN.PartI.dist_integral_le_uniform
#print axioms PaperN.PartI.uniform_integrals_of_compact_parameters
#print axioms PaperN.PartI.uniformWeakIntegrals_uniform
#print axioms PaperN.PartI.tendsto_sup_dist_of_uniform
#print axioms PaperN.PartI.parameterIntegrals_uniform
#print axioms PaperN.PartI.ballMass_tendstoUniformly
#print axioms PaperN.PartI.uniformWeakIntegrals_spec
#print axioms PaperN.PartI.parameterIntegrals_spec
