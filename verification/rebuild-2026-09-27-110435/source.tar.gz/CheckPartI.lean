import PaperN.PartI.Solution

#print PaperN.PartI.MetricBumpStatement
#print PaperN.PartI.NormalizedMetricBumpStatement
#print PaperN.PartI.ContinuousBarycenterStatement
#check @PaperN.PartI.metricBump_spec
#check @PaperN.PartI.normalizedMetricBump_spec
#check @PaperN.PartI.continuousBarycenter_spec
#print axioms PaperN.PartI.metricBump_spec
#print axioms PaperN.PartI.normalizedMetricBump_spec
#print axioms PaperN.PartI.continuousBarycenter_spec
#print axioms PaperN.PartI.probabilityBorel

#print PaperN.PartI.CompactIsometryGroupStatement
#print PaperN.PartI.InvariantFullSupportStatement
#check @PaperN.PartI.compactIsometryGroup_spec
#check @PaperN.PartI.invariantFullSupport_spec
#print axioms PaperN.PartI.compactIsometryGroup_spec
#print axioms PaperN.PartI.invariantFullSupport_spec
