import PaperN.PartI.CommonIsometryGraph

#print PaperN.PartI.IsometryGraphSubsequenceStatement
#check @PaperN.PartI.isometryGraphSubsequence_spec
#check @PaperN.PartI.CommonRealization.isometryGraph_subsequence
#check @PaperN.PartI.CommonRealization.mem_seqGraph
#check @PaperN.PartI.CommonRealization.mem_limitGraph
example {Z : Type*} [MetricSpace Z] (p q : Z × Z) :
    dist p q = max (dist p.1 q.1) (dist p.2 q.2) := rfl
#print axioms PaperN.PartI.mem_isometryGraph
#print axioms PaperN.PartI.exists_tendsto_mem_compacts
#print axioms PaperN.PartI.graph_relation_limit
#print axioms PaperN.PartI.exists_isometry_of_graph_relation
#print axioms PaperN.PartI.isometryGraph_map_fst
#print axioms PaperN.PartI.isometryGraph_map_snd
#print axioms PaperN.PartI.isometryGraphSubsequence_spec
#print axioms PaperN.PartI.CommonRealization.mem_seqGraph
#print axioms PaperN.PartI.CommonRealization.mem_limitGraph
#print axioms PaperN.PartI.CommonRealization.hausdorffConverges_iff
#print axioms PaperN.PartI.CommonRealization.isometryGraph_subsequence
