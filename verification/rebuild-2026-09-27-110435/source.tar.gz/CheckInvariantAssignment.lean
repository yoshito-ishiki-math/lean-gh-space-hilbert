import PaperN.PartI.InvariantAssignment

#print PaperN.PartI.InvariantAssignmentStatement
#check @PaperN.PartI.familyFiberAverage_eq_map
#check @PaperN.PartI.averageConcentratedLaw_tendsto
#check @PaperN.PartI.selectedProbability_tendsto
#check @PaperN.PartI.invariantAssignment_spec
#print axioms PaperN.PartI.map_restrictedLaw_lift
#print axioms PaperN.PartI.familyFiberAverage_eq_map
#print axioms PaperN.PartI.CommonRealization.sequenceEmbedding_isometry
#print axioms PaperN.PartI.CommonRealization.continuous_sequenceImages
#print axioms PaperN.PartI.averageConcentratedLaw_tendsto
#print axioms PaperN.PartI.selectedProbability_tendsto
#print axioms PaperN.PartI.invariantAssignment_spec
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
