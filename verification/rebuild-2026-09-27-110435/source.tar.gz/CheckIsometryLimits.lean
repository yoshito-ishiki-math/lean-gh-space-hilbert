import PaperN.PartI.IsometryLimits

#print PaperN.PartI.IsometryLimitsStatement
#check @PaperN.PartI.isometry_pushforward_tendsto
#check @PaperN.PartI.isometryLimits_spec
#print axioms PaperN.PartI.integral_probabilityPushforward
#print axioms PaperN.PartI.graph_integral_error_tendsto
#print axioms PaperN.PartI.isometry_pushforward_tendsto
#print axioms PaperN.PartI.isometryLimits_spec
