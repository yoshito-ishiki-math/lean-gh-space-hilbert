import PaperN.PartI.InvariantGDelta

#print PaperN.PartI.InvariantGDeltaStatement
#print PaperN.PartI.InvariantFullSupportGDeltaStatement
#print PaperN.PartI.MeasuredCompact.isometryDefect
#print PaperN.PartI.MeasuredGHSpace.invariant
#check @PaperN.PartI.MeasuredGHSpace.isClosed_hasIsometryDefect
#check @PaperN.PartI.invariantGDelta_spec
#check @PaperN.PartI.invariantFullSupportGDelta_spec
#print axioms PaperN.PartI.preimage_thickening_image_isometry
#print axioms PaperN.PartI.levyProkhorovEDist_map_isometry
#print axioms PaperN.PartI.levyProkhorovDist_map_isometry
#print axioms PaperN.PartI.levyProkhorovDist_tendsto
#print axioms PaperN.PartI.isometryDefect_embedding
#print axioms PaperN.PartI.hasIsometryDefect_of_tendsto
#print axioms PaperN.PartI.invariantGDelta_spec
#print axioms PaperN.PartI.invariantFullSupportGDelta_spec
#print axioms PaperN.PartI.CommonRealization.graph_integral_error
#print axioms PaperN.PartI.CommonRealization.actionProbability_tendsto
#print axioms PaperN.PartI.CommonRealization.actionProbability_subsequence
#print axioms PaperN.PartI.CommonRealization.isometryDefect_subsequence
#print axioms PaperN.PartI.MeasuredCompact.isometryDefect_conjugate
#print axioms PaperN.PartI.MeasuredCompact.hasIsometryDefect_of_isomorphic
#print axioms PaperN.PartI.MeasuredCompact.hasIsometryDefect_iff
#print axioms PaperN.PartI.MeasuredCompact.isometryDefect_eq_zero_iff
#print axioms PaperN.PartI.MeasuredCompact.invariant_iff_no_dyadic_defect
#print axioms PaperN.PartI.MeasuredGHSpace.hasIsometryDefect_out
#print axioms PaperN.PartI.MeasuredGHSpace.isClosed_hasIsometryDefect
#print axioms PaperN.PartI.MeasuredGHSpace.invariant_iff_no_dyadic_defect
#print axioms PaperN.PartI.MeasuredGHSpace.invariant_eq_iInter
#print axioms PaperN.PartI.MeasuredGHSpace.invariantFullSupport_iff
