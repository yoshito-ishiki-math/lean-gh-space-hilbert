import PaperN.PartI.FamilyFiberAverage

#print PaperN.PartI.DiracProductConvergenceStatement
#check @PaperN.PartI.probabilityOnSubtype_tendsto
#check @PaperN.PartI.closedDomainAverage_tendsto
#check @PaperN.PartI.continuous_familyFiberProbability
#check @PaperN.PartI.familyFiberAverage_tendsto
#print axioms PaperN.PartI.probability_tendsto_of_closedEmbedding
#print axioms PaperN.PartI.probabilityOnSubtype_tendsto
#print axioms PaperN.PartI.diracProduct_tendsto
#print axioms PaperN.PartI.diracProduct_fullMass
#print axioms PaperN.PartI.closedDomainLaw_tendsto
#print axioms PaperN.PartI.diracProduct_spec
#print axioms PaperN.PartI.closedDomainAverage_tendsto
#print axioms PaperN.PartI.isClosed_familyFiber
#print axioms PaperN.PartI.continuous_familyGH
#print axioms PaperN.PartI.continuous_familyFiberProbability
#print axioms PaperN.PartI.familyFiberAverage_tendsto
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
