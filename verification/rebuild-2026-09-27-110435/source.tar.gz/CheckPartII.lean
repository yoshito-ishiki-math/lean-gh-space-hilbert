import PaperN

#print PaperN.PartII.DistanceKernelSpectralInput
#print PaperN.PartII.DistanceOperatorStatement
#print axioms PaperN.PartII.distanceProfile_norm_le
#print axioms PaperN.PartII.distanceProfile_sub_norm_le
#print axioms PaperN.PartII.continuousToL2_norm_le
#print axioms PaperN.PartII.distanceProfileL2_norm_le
#print axioms PaperN.PartII.distanceProfileL2_sub_norm_le
#print axioms PaperN.PartII.distanceValue_bound
#print axioms PaperN.PartII.distanceValue_sub_bound
#print axioms PaperN.PartII.distanceValue_lipschitz
#print axioms PaperN.PartII.distanceContinuous_norm_le
#print axioms PaperN.PartII.distanceValue_integral
#print axioms PaperN.PartII.distanceIntegrand_integrable
#print axioms PaperN.PartII.distanceValue_integral_of_ae
#print axioms PaperN.PartII.distanceOperator_ae
#print axioms PaperN.PartII.distanceOperator_norm_le
#print axioms PaperN.PartII.continuousToL2_injective
#print axioms PaperN.PartII.eigenfunction_continuousRepresentative
#print axioms PaperN.PartII.distanceOperator_spec
#print axioms PaperN.PartII.selectedDistanceOperator_spectral
#print axioms PaperN.PartII.selectedDistanceOperator_continuousRepresentative
#print axioms PaperN.PartII.distanceProfile_sub_norm
#print axioms PaperN.PartII.distanceProfile_isometry
#print axioms PaperN.PartII.distance_bump_approximation
#print axioms PaperN.PartII.exists_distance_range_approximation
#print axioms PaperN.PartII.distanceProfile_mem_closure_range
#print axioms PaperN.PartII.continuous_kernel_zero
#print axioms PaperN.PartII.distanceToContinuous_eigen_mem
#print axioms PaperN.PartII.distanceToContinuous_mem_uniformSpectralSpan
#print axioms PaperN.PartII.distanceProfile_mem_uniformSpectralSpan
#print axioms PaperN.PartII.finite_eigenfunction_approximation
#print axioms PaperN.PartII.finite_uniform_spectral_approximation
#print axioms PaperN.PartII.finite_spectral_approximation_positive_dim
#print axioms PaperN.PartII.uniformSpectralSpan_spec
#print axioms PaperN.PartII.finiteEigenfunctionApproximation_spec
#print PaperN.PartII.UniformSpectralSpanStatement
#print PaperN.PartII.FiniteEigenfunctionApproximationStatement
#print axioms PaperN.PartII.spectralCutoff_antitone
#print axioms PaperN.PartII.finite_eigenfunctions_le_cutoff
#print axioms PaperN.PartII.spectralCutoff_uniform_approximation
#print axioms PaperN.PartII.spectralCutoff_nonzero
#print PaperN.PartII.CompactEigenvalueFinitenessInput
#print axioms PaperN.PartII.spectralCutoff_map_eq
#print axioms PaperN.PartII.spectralCutoffEquiv
#print axioms PaperN.PartII.l2SpectralCutoff_finiteDimensional_of_finite
#print axioms PaperN.PartII.spectralCutoff_finiteDimensional_of_finite
#print axioms PaperN.PartII.spectralCutoff_finrank_eq
#print axioms PaperN.PartII.spectralCutoff_finiteDimensional
#print axioms PaperN.PartII.spectralCutoff_positive_finrank
#print PaperN.PartII.complexifiedSpectrum
#print PaperN.PartII.SpectralDensityStatement
#print axioms PaperN.PartII.ofReal_not_mem_complexifiedSpectrum
#print axioms PaperN.PartII.complexScalar_apply
#print axioms PaperN.PartII.commutes_complexStructure_iff
#print axioms PaperN.PartII.not_mem_complexifiedSpectrum_iff
#print axioms PaperN.PartII.complexResolventBlock_apply
#print axioms PaperN.PartII.exists_complexified_spectral_gap
#print axioms PaperN.PartII.spectral_density
#print axioms PaperN.PartII.spectralDensity_spec
#print axioms PaperN.PartII.selectedSpectralDensity
#print PaperN.PartII.MinimizerContinuityStatement
#print axioms PaperN.PartII.minimizer_tendsto
#print axioms PaperN.PartII.minimizerContinuity_spec
#print axioms PaperN.PartII.exists_uniform_ball_mass
#print axioms PaperN.PartII.uniform_ball_mass_pos
#print PaperN.PartII.LpDistanceStatement
#print axioms PaperN.PartII.distanceDifferenceLp_eq_sub
#print axioms PaperN.PartII.distanceDifferenceLp_norm_le
#print axioms PaperN.PartII.distanceDifferenceLp_norm_lower
#print axioms PaperN.PartII.distanceDifferenceLp_error
#print axioms PaperN.PartII.lpDistance_spec
#print axioms PaperN.PartII.selectedLpDistance
#print axioms PaperN.PartII.factor_shift_pow
#print axioms PaperN.PartII.factor_shift_pow_of_restrict_zero
#print axioms PaperN.PartII.factor_power_kernel_restrict_zero
#print axioms PaperN.PartII.factorEigenspaceEquiv
#print axioms PaperN.PartII.factorEigenspaceEquiv_apply
#print axioms PaperN.PartII.factorEigenspaceEquiv_symm_apply
#print axioms PaperN.PartII.factor_power_kernel_eq
#print axioms PaperN.PartII.factor_hasEigenvalue_iff
#print axioms PaperN.PartII.factor_maxGenEigenspace_eq
#print axioms PaperN.PartII.symmetric_power_kernel
#print axioms PaperN.PartII.factor_mem_spectrum_iff
#print axioms PaperN.PartII.factor_nonzero_spectrum_eq
#print axioms PaperN.PartII.factor_symmetric_power_kernel
#print axioms PaperN.PartII.factor_symmetric_maxGenEigenspace
#print axioms PaperN.PartII.factorGeneralizedEigenspaceEquiv
#print axioms PaperN.PartII.factorGeneralizedEigenspaceEquiv_apply
#print axioms PaperN.PartII.factorGeneralizedEigenspaceEquiv_symm_apply
#print axioms PaperN.PartII.ComplexKernel.distanceProfile_norm_le
#print axioms PaperN.PartII.ComplexKernel.distanceProfile_sub_norm_le
#print axioms PaperN.PartII.ComplexKernel.continuousToL2_norm_le
#print axioms PaperN.PartII.ComplexKernel.distanceProfileL2_norm_le
#print axioms PaperN.PartII.ComplexKernel.distanceProfileL2_sub_norm_le
#print axioms PaperN.PartII.ComplexKernel.distanceValue_bound
#print axioms PaperN.PartII.ComplexKernel.distanceValue_sub_bound
#print axioms PaperN.PartII.ComplexKernel.distanceValue_lipschitz
#print axioms PaperN.PartII.ComplexKernel.distanceContinuous_norm_le
#print axioms PaperN.PartII.ComplexKernel.distanceValue_integral
#print axioms PaperN.PartII.ComplexKernel.distanceIntegrand_integrable
#print axioms PaperN.PartII.ComplexKernel.distanceValue_integral_of_ae
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_ae
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_norm_le
#print axioms PaperN.PartII.ComplexKernel.continuousToL2_injective
#print axioms PaperN.PartII.ComplexKernel.eigenfunction_continuousRepresentative
#print axioms PaperN.PartII.ComplexKernel.continuousDistanceOperator_integral
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_intertwine
#print axioms PaperN.PartII.AmbientKernel.distanceProfile_norm_le
#print axioms PaperN.PartII.AmbientKernel.distanceProfile_sub_norm_le
#print axioms PaperN.PartII.AmbientKernel.distanceProfileL2_norm_le
#print axioms PaperN.PartII.AmbientKernel.distanceProfileL2_sub_norm_le
#print axioms PaperN.PartII.AmbientKernel.distanceValue_bound
#print axioms PaperN.PartII.AmbientKernel.distanceValue_sub_bound
#print axioms PaperN.PartII.AmbientKernel.distanceValue_lipschitz
#print axioms PaperN.PartII.AmbientKernel.distanceContinuous_norm_le
#print axioms PaperN.PartII.AmbientKernel.distanceValue_integral
#print axioms PaperN.PartII.AmbientKernel.distanceIntegrand_integrable
#print axioms PaperN.PartII.AmbientKernel.distanceValue_integral_of_ae
#print axioms PaperN.PartII.AmbientKernel.restrictionContinuous_norm_le
#print axioms PaperN.PartII.AmbientKernel.restriction_norm_le
#print axioms PaperN.PartII.AmbientKernel.restriction_extension
#print axioms PaperN.PartII.AmbientKernel.restriction_intertwine
#print axioms PaperN.PartII.AmbientKernel.ambientOperator_integral
#print axioms PaperN.PartII.AmbientKernel.ambient_hasEigenvalue_iff
#print axioms PaperN.PartII.AmbientKernel.distanceToContinuous_compact
#print axioms PaperN.PartII.AmbientKernel.ambientOperator_compact
#print axioms PaperN.PartII.AmbientKernel.distanceOperator_compact
#print axioms PaperN.PartII.AmbientKernel.ambient_nonzero_spectrum_eq
#print axioms PaperN.PartII.ComplexKernel.distancePair_integrable
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_symmetric
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_selfAdjoint
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_opNorm_le
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_spectrum_bound
#print axioms PaperN.PartII.AmbientKernel.restriction_extension_symmetric
#print axioms PaperN.PartII.AmbientKernel.ambient_power_kernel
#print axioms PaperN.PartII.AmbientKernel.ambient_maxGenEigenspace
#print axioms PaperN.PartII.AmbientKernel.ambient_spectrum_interval
#print axioms PaperN.PartII.AmbientKernel.distance_maxGenEigenspace
#print axioms PaperN.PartII.AmbientKernel.distance_power_kernel
#print axioms PaperN.PartII.AmbientKernel.restrictionGeneralizedEquiv
#print axioms PaperN.PartII.AmbientKernel.restrictionGeneralizedEquiv_apply
#print axioms PaperN.PartII.AmbientKernel.restrictionGeneralizedEquiv_symm_apply
#print axioms PaperN.PartII.ambientEigenspaces_spec
#print axioms PaperN.PartII.selectedAmbientEigenspaces
#print axioms PaperN.PartII.inverse_intertwine
#print axioms PaperN.PartII.resolvent_intertwine
#print axioms PaperN.PartII.integral_resolvent_intertwine
#print axioms PaperN.PartII.AmbientKernel.restriction_resolvent
#print axioms PaperN.PartII.AmbientKernel.nonzero_resolventSet_iff
#print axioms PaperN.PartII.AmbientKernel.restriction_resolvent_of_nonzero
#print axioms PaperN.PartII.integratedResolvent_apply
#print axioms PaperN.PartII.integratedResolvent_intertwine
#print axioms PaperN.PartII.integratedResolvent_range_map_le
#print axioms PaperN.PartII.AmbientKernel.restriction_integratedResolvent
#print axioms PaperN.PartII.continuous_weighted_resolvent
#print axioms PaperN.PartII.integrable_weighted_resolvent
#print axioms PaperN.PartII.compact_integratedResolvent_intertwine
#print axioms PaperN.PartII.AmbientKernel.restriction_compact_integratedResolvent
#print axioms PaperN.PartII.segmentResolvent_integrable
#print axioms PaperN.PartII.segmentResolvent_intertwine
#print axioms PaperN.PartII.quadrilateralResolvent_intertwine
#print axioms PaperN.PartII.mem_resolvent_of_im_ne_zero
#print axioms PaperN.PartII.mem_resolvent_of_re
#print axioms PaperN.PartII.rectangle_edges_resolvent
#print axioms PaperN.PartII.rectangleResolvent_intertwine
#print axioms PaperN.PartII.cutoffRectangles_spectral_selection
#print axioms PaperN.PartII.cutoffOuter_gt
#print axioms PaperN.PartII.cutoffOuter_resolvent
#print axioms PaperN.PartII.cutoffContourOperator_intertwine
#print axioms PaperN.PartII.cutoffContour_spectral_selection
#print axioms PaperN.PartII.zero_not_mem_closure_cutoffRectangles
#print axioms PaperN.PartII.resolvent_apply_eigenvector
#print axioms PaperN.PartII.segmentResolvent_apply_eigenvector
#print axioms PaperN.PartII.quadrilateralResolvent_apply_eigenvector
#print axioms PaperN.PartII.quadrilateralResolvent_fixes_eigenvector
#print axioms PaperN.PartII.quadrilateralResolvent_kills_eigenvector
#print axioms PaperN.PartII.rectangleResolvent_apply_eigenvector
#print axioms PaperN.PartII.cutoffContourOperator_apply_eigenvector
#print axioms PaperN.PartII.scalarCircle_inside
#print axioms PaperN.PartII.scalarCircle_outside
#print axioms PaperN.PartII.scalarCircle_real_interval_inside
#print axioms PaperN.PartII.scalarCircle_real_interval_outside
#print axioms PaperN.PartII.scalarCircle_cutoff_pair
#print axioms PaperN.PartII.circleResolvent_integrable
#print axioms PaperN.PartII.circleResolvent_apply
#print axioms PaperN.PartII.circleResolvent_apply_eigenvector
#print axioms PaperN.PartII.circleResolvent_fixes_inside
#print axioms PaperN.PartII.circleResolvent_kills_outside
#print axioms PaperN.PartII.idempotent_of_dense_eigenspaces
#print axioms PaperN.PartII.circleResolvent_idempotent
#print axioms PaperN.PartII.circleResolvent_idempotent_of_compact_symmetric
#print axioms PaperN.PartII.ComplexKernel.distance_circleResolvent_idempotent
#print axioms PaperN.PartII.range_eq_closedEigenSpan
#print axioms PaperN.PartII.ker_eq_closedEigenSpan_compl
#print axioms PaperN.PartII.circleResolvent_kills_not_inside
#print axioms PaperN.PartII.circleResolvent_range
#print axioms PaperN.PartII.circleResolvent_ker
#print axioms PaperN.PartII.circleResolvent_range_of_compact_symmetric
#print axioms PaperN.PartII.circleResolvent_ker_of_compact_symmetric
#print axioms PaperN.PartII.closedEigenSpan_compl_le_orthogonal
#print axioms PaperN.PartII.circleResolvent_eq_starProjection
#print axioms PaperN.PartII.ComplexKernel.distance_circleResolvent_range
#print axioms PaperN.PartII.ComplexKernel.distance_circleResolvent_ker
#print axioms PaperN.PartII.ComplexKernel.distance_circleResolvent_eq_starProjection
#print axioms PaperN.PartII.selector_eq_starProjection
#print axioms PaperN.PartII.twoCircleResolvent_fixes
#print axioms PaperN.PartII.twoCircleResolvent_kills
#print axioms PaperN.PartII.twoCircleResolvent_eq_starProjection
#print axioms PaperN.PartII.circle_real_interval_resolvent
#print axioms PaperN.PartII.real_mem_interval_ball
#print axioms PaperN.PartII.cutoffCircle_balls_disjoint
#print axioms PaperN.PartII.cutoffCircle_real_selection
#print axioms PaperN.PartII.cutoffCircle_apply_eigenvector
#print axioms PaperN.PartII.cutoffCircle_eq_starProjection
#print axioms PaperN.PartII.ComplexKernel.distance_cutoffCircle_eq_starProjection
#print axioms PaperN.PartII.ComplexKernel.distance_cutoffCircle_explicit
#print axioms PaperN.PartII.complex_cutoff_eigenvalues_finite
#print axioms PaperN.PartII.complexAlgebraicCutoff_finiteDimensional
#print axioms PaperN.PartII.closedEigenSpan_cutoff_eq_algebraic
#print axioms PaperN.PartII.cutoffCircle_range_eq_algebraic
#print axioms PaperN.PartII.cutoffCircle_range_finiteDimensional
#print axioms PaperN.PartII.ComplexKernel.distance_cutoffCircle_range_eq_algebraic
#print axioms PaperN.PartII.ComplexKernel.distance_complexAlgebraicCutoff_finiteDimensional
#print axioms PaperN.PartII.circleResolvent_intertwine
#print axioms PaperN.PartII.twoCircleResolvent_intertwine
#print axioms PaperN.PartII.cutoffCircle_spheres_resolvent
#print axioms PaperN.PartII.cutoffCircle_intertwine
#print axioms PaperN.PartII.AmbientKernel.restriction_cutoffCircle
#print axioms PaperN.PartII.AmbientKernel.restriction_cutoffCircle_explicit
#print axioms PaperN.PartII.seminorm_continuous_finiteDimensional
#print axioms PaperN.PartII.seminorm_le_of_unit_bound
#print axioms PaperN.PartII.seminorm_difference_le_of_unit_bound
#print axioms PaperN.PartII.coordinate_pair_estimate
#print axioms PaperN.PartII.coordinate_correspondence_estimate
#print axioms PaperN.PartII.coordinate_correspondence_sup_estimate
#print axioms PaperN.PartII.unitNormBound_attained
#print axioms PaperN.PartII.coordinate_pseudometric_estimate
#print axioms PaperN.PartII.coordinatePseudometricEstimate_spec
#print axioms PaperN.PartII.factor_map_eigenspace
#print axioms PaperN.PartII.factor_map_selectedEigenspaces
#print axioms PaperN.PartII.factor_selected_restrict_zero
#print axioms PaperN.PartII.factorSelectedEigenspacesEquiv
#print axioms PaperN.PartII.factorSelectedEigenspacesEquiv_apply
#print axioms PaperN.PartII.AmbientKernel.restriction_map_selected
#print axioms PaperN.PartII.AmbientKernel.restriction_selected_zero
#print axioms PaperN.PartII.AmbientKernel.restrictionSelectedEquiv
#print axioms PaperN.PartII.AmbientKernel.restrictionSelectedEquiv_apply
#print axioms PaperN.PartII.AmbientKernel.restrictionCutoffEquiv
#print axioms PaperN.PartII.AmbientKernel.restrictionCutoffEquiv_apply
#print axioms PaperN.PartII.AmbientKernel.ambientCutoff_finiteDimensional
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoff_generalized_eq
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffCircle_range
#print axioms PaperN.PartII.AmbientKernel.restrictionCircleRangeEquiv
#print axioms PaperN.PartII.AmbientKernel.restrictionCircleRangeEquiv_apply
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffCircle_idempotent

#print axioms PaperN.PartII.ComplexKernel.realPart_ae
#print axioms PaperN.PartII.ComplexKernel.imagPart_ae
#print axioms PaperN.PartII.ComplexKernel.realEmbed_ae
#print axioms PaperN.PartII.ComplexKernel.realEmbed_parts
#print axioms PaperN.PartII.ComplexKernel.realPart_realEmbed
#print axioms PaperN.PartII.ComplexKernel.realEmbed_injective
#print axioms PaperN.PartII.ComplexKernel.imagPart_realEmbed
#print axioms PaperN.PartII.ComplexKernel.realPart_complex_smul
#print axioms PaperN.PartII.ComplexKernel.imagPart_complex_smul
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_realPart
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_imagPart
#print axioms PaperN.PartII.ComplexKernel.distanceOperator_realEmbed
#print axioms PaperN.PartII.ComplexKernel.realPart_eigenvector
#print axioms PaperN.PartII.ComplexKernel.imagPart_eigenvector
#print axioms PaperN.PartII.ComplexKernel.realEmbed_eigenvector
#print axioms PaperN.PartII.ComplexKernel.realEmbed_mem_complexCutoff
#print axioms PaperN.PartII.ComplexKernel.complexCutoff_eq_complexification
#print axioms PaperN.PartII.ComplexKernel.parts_mem_of_mem_complexification
#print axioms PaperN.PartII.ComplexKernel.mem_complexCutoff_iff_real_imag
#print axioms PaperN.PartII.ComplexKernel.mem_complexCutoff_iff_continuous_real_imag

#print axioms PaperN.PartII.ComplexKernel.inner_realEmbed
#print axioms PaperN.PartII.ComplexKernel.cutoff_starProjection_realEmbed
#print axioms PaperN.PartII.ComplexKernel.cutoff_starProjection_real_imag
#print axioms PaperN.PartII.ComplexKernel.realCutoff_finiteDimensional
#print axioms PaperN.PartII.ComplexKernel.realCutoffProjection
#print axioms PaperN.PartII.ComplexKernel.distance_cutoffCircle_realEmbed
#print axioms PaperN.PartII.ComplexKernel.distance_cutoffCircle_real_imag
#print axioms PaperN.PartII.ComplexKernel.distance_cutoffCircle_preserves_real
#print axioms PaperN.PartII.AmbientKernel.restriction_cutoffCircle_real_imag

#print axioms PaperN.PartII.ComplexKernel.continuousRealEmbed
#print axioms PaperN.PartII.ComplexKernel.continuousToL2_realEmbed
#print axioms PaperN.PartII.ComplexKernel.realProjectionRepresentative
#print axioms PaperN.PartII.ComplexKernel.realProjectionRepresentative_toL2
#print axioms PaperN.PartII.ComplexKernel.continuousCutoffProjection
#print axioms PaperN.PartII.ComplexKernel.continuousCutoffProjection_toL2
#print axioms PaperN.PartII.AmbientKernel.restriction_cutoffCircle_continuous
#print axioms PaperN.PartII.AmbientKernel.restriction_cutoffCircle_pointwise

#print axioms PaperN.PartII.AmbientKernel.ambientOperator_star
#print axioms PaperN.PartII.AmbientKernel.restriction_star
#print axioms PaperN.PartII.AmbientKernel.star_mem_ambientCutoff
#print axioms PaperN.PartII.AmbientKernel.ambientCutoff_real_of_restriction_real
#print axioms PaperN.PartII.ComplexKernel.star_realEmbed
#print axioms PaperN.PartII.AmbientKernel.restriction_continuousRealEmbed
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffCircle_preserves_real
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffCircle_real_pointwise

#print axioms PaperN.PartII.ComplexKernel.continuousComplexCutoff
#print axioms PaperN.PartII.ComplexKernel.mem_continuousComplexCutoff_iff
#print axioms PaperN.PartII.ComplexKernel.continuousCutoffEquiv
#print axioms PaperN.PartII.ComplexKernel.continuousCutoffEquiv_apply
#print axioms PaperN.PartII.ComplexKernel.continuousCutoffEquiv_symm_toL2
#print axioms PaperN.PartII.AmbientKernel.restrictionContinuousCircleRangeEquiv
#print axioms PaperN.PartII.AmbientKernel.restrictionContinuousCircleRangeEquiv_apply
#print axioms PaperN.PartII.AmbientKernel.CircularProjectionRestrictionStatement
#print axioms PaperN.PartII.AmbientKernel.circularProjectionRestriction_spec
#print axioms PaperN.PartII.AmbientKernel.circularProjectionRestriction_explicit

#print axioms PaperN.PartII.RectangleCircleResolventInput
#print axioms PaperN.PartII.cutoffContour_eq_circle
#print axioms PaperN.PartII.AmbientKernel.ambient_spectrum_bound_source
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffContour_eq_circle
#print axioms PaperN.PartII.AmbientKernel.ProjectionRestrictionStatement
#print axioms PaperN.PartII.AmbientKernel.projectionRestriction_spec

#print axioms PaperN.PartII.AmbientKernel.measureOperator
#print axioms PaperN.PartII.AmbientKernel.measureOperator_integral
#print axioms PaperN.PartII.AmbientKernel.measureOperator_strong
#print axioms PaperN.PartII.AmbientKernel.measureOperator_collectivelyCompact
#print axioms PaperN.PartII.AmbientKernel.measureOperator_differences_collectivelyCompact
#print axioms PaperN.PartII.AmbientKernel.ambientOperator_eq_measureOperator
#print axioms PaperN.PartII.AmbientKernel.ambientOperator_strong_of_pushforward
#print axioms PaperN.PartII.AmbientKernel.ambientOperator_collectivelyCompact

#print axioms PaperN.PartII.AmbientKernel.selectedSequenceOperator
#print axioms PaperN.PartII.AmbientKernel.selectedLimitOperator
#print axioms PaperN.PartII.AmbientKernel.selectedSequenceOperator_strong
#print axioms PaperN.PartII.AmbientKernel.selectedSequenceOperator_collectivelyCompact
#print axioms PaperN.PartII.AmbientKernel.selectedSequenceOperator_differences_collectivelyCompact
#print axioms PaperN.PartII.AmbientKernel.selectedLimitOperator_compact

#print axioms PaperN.PartII.CollectivelyCompactSpectralInclusionInput
#print axioms PaperN.PartII.AmbientKernel.selectedSequenceOperator_eventually_resolvent
#print axioms PaperN.PartII.AmbientKernel.selectedDistanceOperator_eventually_cutoff_resolvent

#print axioms PaperN.PartII.CutoffProjectionConvergenceInput
#print axioms PaperN.PartII.AmbientKernel.selectedLimitOperator_spectrum_bound
#print axioms PaperN.PartII.AmbientKernel.selectedCutoffProjection_convergence
#print axioms PaperN.PartII.AmbientKernel.selectedLimitProjection_finiteDimensional
#print axioms PaperN.PartII.AmbientKernel.selectedCutoffProjection_eventual_rank

#print axioms PaperN.PartII.ComplexKernel.cutoffRealPairEquiv
#print axioms PaperN.PartII.ComplexKernel.complexCutoff_finrank_eq_real
#print axioms PaperN.PartII.ComplexKernel.complexCutoff_finrank_eq_continuous_real
#print axioms PaperN.PartII.AmbientKernel.ambientProjection_finrank_eq_realCutoff
#print axioms PaperN.PartII.AmbientKernel.selectedCutoff_eventual_real_dimension

#print axioms PaperN.PartII.AmbientKernel.SpectralProjectionProperties
#print axioms PaperN.PartII.AmbientKernel.ambient_commonContour_properties
#print axioms PaperN.PartII.AmbientKernel.SpectralProjectionsStatement
#print axioms PaperN.PartII.AmbientKernel.spectralProjections_spec

#print axioms PaperN.PartII.AmbientKernel.ambient_cutoff_spectrum_iSup

#print axioms PaperN.PartII.varying_integral_tendsto
#print axioms PaperN.PartII.continuousGram
#print axioms PaperN.PartII.continuousGram_tendsto
#print axioms PaperN.PartII.continuousGram_eventually_isUnit

#print axioms PaperN.PartII.transformContinuousBasis
#print axioms PaperN.PartII.transformContinuousBasis_one
#print axioms PaperN.PartII.transformContinuousBasis_mem
#print axioms PaperN.PartII.transformContinuousBasis_tendsto
#print axioms PaperN.PartII.transformContinuousBasis_tendsto_identity
#print axioms PaperN.PartII.continuousGram_transform

#print axioms PaperN.PartII.continuousGram_isHermitian
#print axioms PaperN.PartII.continuousGram_quadratic
#print axioms PaperN.PartII.continuousGram_posSemidef
#print axioms PaperN.PartII.continuousGram_eventually_posDef

#print axioms PaperN.PartII.gramNormalizer
#print axioms PaperN.PartII.gramNormalizer_identity
#print axioms PaperN.PartII.gramNormalizer_tendsto_one
#print axioms PaperN.PartII.normalizeContinuousFamily
#print axioms PaperN.PartII.normalizeContinuousFamily_gram
#print axioms PaperN.PartII.normalizeContinuousFamily_tendsto
#print axioms PaperN.PartII.normalizeContinuousFamily_eventually_gram

#print axioms PaperN.PartII.ComplexKernel.continuousRealPart
#print axioms PaperN.PartII.ComplexKernel.continuousRealPart_apply
#print axioms PaperN.PartII.ComplexKernel.continuousRealPart_embed
#print axioms PaperN.PartII.ComplexKernel.continuousRealEmbed_realPart
#print axioms PaperN.PartII.ComplexKernel.realProjectedFunction
#print axioms PaperN.PartII.ComplexKernel.realProjectedFunction_tendsto
#print axioms PaperN.PartII.ComplexKernel.continuousRealPart_mem_cutoff
#print axioms PaperN.PartII.AmbientKernel.realPart_restrict_mem_cutoff
#print axioms PaperN.PartII.AmbientKernel.realProjectedFunction_mem_cutoff

#print axioms PaperN.PartII.AmbientKernel.exists_real_cutoff_extension
#print axioms PaperN.PartII.AmbientKernel.realProjectedFunction_eq_of_mem
#print axioms PaperN.PartII.AmbientKernel.exists_real_projected_extension
#print axioms PaperN.PartII.AmbientKernel.exists_convergent_projected_extensions

#print axioms PaperN.PartII.continuousToL2_inner
#print axioms PaperN.PartII.continuousGram_map
#print axioms PaperN.PartII.continuousGram_eq_one_iff
#print axioms PaperN.PartII.continuousGram_map_eq_one
#print axioms PaperN.PartII.normalized_restrictions_orthonormal
#print axioms PaperN.PartII.orthonormal_continuousFamily_span

#print axioms PaperN.PartII.uniform_function_nearby_convergence
#print axioms PaperN.PartII.finite_family_nearby_convergence
#print axioms PaperN.PartII.nearby_family_sup_tendsto

#print axioms PaperN.PartII.normalize_restrict_mem
#print axioms PaperN.PartII.AmbientKernel.selected_spectral_basis_extensions

#print axioms PaperN.PartII.finite_family_norm_tendsto
#print axioms PaperN.PartII.AmbientKernel.spectralContinuity_spec

#print axioms PaperN.PartII.NormedCoordinatePair.equivalent_refl
#print axioms PaperN.PartII.NormedCoordinatePair.equivalent_symm
#print axioms PaperN.PartII.NormedCoordinatePair.equivalent_trans
#print axioms PaperN.PartII.NormedCoordinatePair.pseudometric_eq_of_equivalent
#print axioms PaperN.PartII.NormedCoordinatePair.norm_coordinates_eq_of_equivalent
#print axioms PaperN.PartII.NormedCoordinateClass.pseudometric
#print axioms PaperN.PartII.NormedCoordinateClass.value
#print axioms PaperN.PartII.NormedCoordinateClass.value_mk
#print axioms PaperN.PartII.NormedCoordinateClass.pseudometric_mk

#print axioms PaperN.PartII.coordinateSynthesis_injective

#print axioms PaperN.PartII.coordinateLpNorm_apply

#print axioms PaperN.PartII.coordinateLpNorm_definite

#print axioms PaperN.PartII.coordinateLpPair

#print axioms PaperN.PartII.coordinateLpNorm_le_two_diam

#print axioms PaperN.PartII.exists_bestApproximation

#print axioms PaperN.PartII.bestApproximation_unique

#print axioms PaperN.PartII.exists_coordinateLp_minimizer

#print axioms PaperN.PartII.coordinateLp_minimizer_unique

#print axioms PaperN.PartII.coordinateLpMinimizer

#print axioms PaperN.PartII.coordinateLpMinimizer_spec

#print axioms PaperN.PartII.coordinateLpMinimizer_norm_le_two_diam

#print axioms PaperN.PartII.bestApproximation

#print axioms PaperN.PartII.bestApproximation_spec

#print axioms PaperN.PartII.bestApproximation_norm_le

#print axioms PaperN.PartII.bestApproximation_tendsto

#print axioms PaperN.PartII.continuous_bestApproximation

#print axioms PaperN.PartII.continuous_coordinateLpMinimizer

#print axioms PaperN.PartII.bestApproximationCoordinates

#print axioms PaperN.PartII.bestApproximation_isometry

#print axioms PaperN.PartII.coordinateLpMinimizer_change_basis

#print axioms PaperN.PartII.coordinateLpNorm_change_basis

#print axioms PaperN.PartII.bestApproximationCoordinatePair

#print axioms PaperN.PartII.bestApproximationCoordinatePair_equivalent

#print axioms PaperN.PartII.bestApproximationCoordinatePair_class_eq

#print axioms PaperN.PartII.orthonormalCoordinateChange

#print axioms PaperN.PartII.synthesis_toLp_basis

#print axioms PaperN.PartII.coordinateSynthesis_change_basis

#print axioms PaperN.PartII.coordinateLpMap_change_orthonormal_basis

#print axioms PaperN.PartII.bestApproximationCoordinatePair_class_eq_of_orthonormal_bases

#print axioms PaperN.PartII.continuousSubspaceL2Equiv

#print axioms PaperN.PartII.continuousFamilyL2_orthonormal

#print axioms PaperN.PartII.continuousFamilyOrthonormalBasis

#print axioms PaperN.PartII.continuousFamilyOrthonormalBasis_apply

#print axioms PaperN.PartII.coordinate_class_independent_of_full_orthonormal_family

#print axioms PaperN.PartII.norm_sub_error_le

#print axioms PaperN.PartII.bestApproximation_pseudometric_error_le

#print axioms PaperN.PartII.bestApproximation_pseudometric_dist_error_le

#print axioms PaperN.PartII.bestApproximation_pseudometric_error_of_uniform_competitors

#print axioms PaperN.PartII.bestApproximation_pseudometric_ball_mass_error
#print axioms PaperN.PartII.bestApproximation_pseudometric_uniform_error

#print axioms PaperN.PartII.exists_large_exponent
#print axioms PaperN.PartII.exists_local_error_parameters

#print axioms PaperN.PartII.exists_uniform_subspace_competitor
#print axioms PaperN.PartII.exists_spectral_competitors

#print axioms PaperN.PartII.exists_coordinateSynthesis_eq
#print axioms PaperN.PartII.exists_uniform_coefficient_competitor
#print axioms PaperN.PartII.based_subspace_uniform_model_error

#print axioms PaperN.PartII.exists_center_approximation_parameters

#print axioms PaperN.PartII.exists_continuous_orthonormal_basis
#print axioms PaperN.PartII.exists_center_coordinates

#print axioms PaperN.PartII.coordinateSynthesis_error_le
#print axioms PaperN.PartII.coordinateSynthesis_uniform_on_ball

#print axioms PaperN.PartII.continuousAbsPower_tendsto
#print axioms PaperN.PartII.varying_absPower_integral_tendsto
#print axioms PaperN.PartII.varying_absPower_integral_uniform

#print axioms PaperN.PartII.parameterizedSynthesis_tendsto
#print axioms PaperN.PartII.synthesis_power_integrals_uniform
#print axioms PaperN.PartII.residual_power_integrals_uniform

#print axioms PaperN.PartII.distanceObjective_uniform_on_compact
#print axioms PaperN.PartII.distanceObjective_uniform_on_ball
#print axioms PaperN.PartII.distanceObjective_sup_error_tendsto

#print axioms PaperN.PartII.continuous_distanceObjective
#print axioms PaperN.PartII.distanceObjective_moving_uniform_on_compact
#print axioms PaperN.PartII.distanceObjective_minimizers_tendsto

#print axioms PaperN.PartII.continuous_toLp_norm_mono
#print axioms PaperN.PartII.coefficient_norm_le_coordinateLpNorm
#print axioms PaperN.PartII.coordinateLpMinimizer_coefficient_norm_le_two_diam

#print axioms PaperN.PartII.continuous_toLp_norm_rpow
#print axioms PaperN.PartII.distanceObjective_eq_norm_rpow
#print axioms PaperN.PartII.distanceObjective_le_iff_norm_le
#print axioms PaperN.PartII.coordinateLpMinimizer_objective_minimal
#print axioms PaperN.PartII.distanceObjective_minimizer_eq

#print axioms PaperN.PartII.distanceObjective_map_isometry
#print axioms PaperN.PartII.coordinateLpMinimizer_mapped_objective_minimal
#print axioms PaperN.PartII.mapped_distanceObjective_minimizer_eq

#print axioms PaperN.PartII.embedded_coordinateLpMinimizer_tendsto
#print axioms PaperN.PartII.embedded_coordinateLpMinimizer_bounded
#print axioms PaperN.PartII.embedded_orthonormal_coordinateLpMinimizer_tendsto

#print axioms PaperN.PartII.isBounded_range_of_eventually_norm_le
#print axioms PaperN.PartII.embedded_eventually_orthonormal_coordinateLpMinimizer_tendsto

#print axioms PaperN.PartII.exists_orthonormalBasis_of_orthonormal
#print axioms PaperN.PartII.embedded_orthonormal_family_coefficient_tendsto

#print axioms PaperN.PartII.AmbientKernel.selected_spectral_coefficients_tendsto

#print axioms PaperN.PartII.varying_continuous_Lp_norm_tendsto
#print axioms PaperN.PartII.coordinateLpNorm_tendsto

#print axioms PaperN.PartII.coordinateLpNorm_uniform_on_compact
#print axioms PaperN.PartII.coordinateLpNorm_uniform_on_ball

#print axioms PaperN.PartII.coordinateLpNorm_map
#print axioms PaperN.PartII.intrinsic_coordinateLpNorm_uniform_on_compact

#print axioms PaperN.PartII.AmbientKernel.selected_spectral_coordinates_and_norms_tendsto
#print axioms PaperN.PartII.intrinsic_coordinateLpNorm_sub_tendsto

#print axioms PaperN.PartII.uniform_relation_of_sequential
#print axioms PaperN.PartII.uniform_nearby_of_sequential

#print axioms PaperN.PartII.embedded_coefficient_uniform_nearby
#print axioms PaperN.PartII.AmbientKernel.selected_spectral_coordinates_uniform_nearby

#print axioms PaperN.PartII.varying_sup_dist_tendsto
#print axioms PaperN.PartII.nearby_pair_sup_tendsto
#print axioms PaperN.PartII.coordinateLpNorm_unitNormError_tendsto

#print axioms PaperN.PartII.AmbientKernel.selected_spectral_model_sup_convergence

#print axioms PaperN.PartII.exists_continuous_orthonormal_basis_fin
#print axioms PaperN.PartII.subspaceOrthonormalBasis_orthonormal
#print axioms PaperN.PartII.subspaceCoordinateClass_eq_of_orthonormal_family

#print axioms PaperN.PartII.repair_coordinate_class_representatives
#print axioms PaperN.PartII.coordinate_class_repair_preserves_suprema

#print axioms PaperN.PartII.exists_subspace_class_representative
#print axioms PaperN.PartII.repair_subspace_class_families
#print axioms PaperN.PartII.exists_spectral_class_representative

#print axioms PaperN.PartII.exists_convergent_subspace_representatives

#print axioms PaperN.PartII.AmbientKernel.selectedSpectralCoordinateClass
#print axioms PaperN.PartII.AmbientKernel.selected_spectral_class_representatives_converge

#print axioms PaperN.PartII.AmbientKernel.exists_spectral_rank_gap_ball

#print axioms PaperN.PartII.AmbientKernel.exists_spectralModelNeighborhood
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.coordinateClass
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.representatives_converge

#print axioms PaperN.PartII.subspaceCoordinateClass_value_le_two_diam
#print axioms PaperN.PartII.subspaceCoordinateClass_representative_bound
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.representative_bound

#print axioms PaperN.PartII.AmbientKernel.exists_center_class_approximation

#print axioms PaperN.PartII.complexResolventBlock_injective_of_not_mem
#print axioms PaperN.PartII.ComplexKernel.ofReal_mem_resolventSet_of_not_mem_complexifiedSpectrum
#print axioms PaperN.PartII.AmbientKernel.exists_center_class_approximation_resolvent

#print axioms PaperN.PartII.AmbientKernel.exists_approximating_spectral_neighborhood

#print axioms PaperN.PartII.uniform_metric_error_eq_norm
#print axioms PaperN.PartII.uniform_metric_error_comparison
#print axioms PaperN.PartII.uniform_metric_error_tendsto
#print axioms PaperN.PartII.coordinate_metric_error_tendsto

#print axioms PaperN.PartII.coordinateBound_le_error_add
#print axioms PaperN.PartII.coordinateBound_eventually_le_of_error_tendsto
#print axioms PaperN.PartII.coordinate_metric_error_tendsto_of_errors

#print axioms PaperN.PartI.CommonRealization.exists_correspondences_tendsto
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.metric_error_tendsto

#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.metricError
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.exists_metric_error_ball

#print axioms PaperN.PartII.NormedCoordinatePair.comap
#print axioms PaperN.PartII.NormedCoordinatePair.equivalent_comap
#print axioms PaperN.PartII.NormedCoordinateClass.comap
#print axioms PaperN.PartII.NormedCoordinateClass.comap_mk
#print axioms PaperN.PartII.NormedCoordinateClass.value_comap
#print axioms PaperN.PartII.NormedCoordinateClass.pseudometric_comap_apply
#print axioms PaperN.PartII.NormedCoordinateClass.comap_id
#print axioms PaperN.PartII.NormedCoordinateClass.comap_comp
#print axioms PaperN.PartII.NormedCoordinateClass.comapEquiv

#print axioms PaperN.PartII.coordinateLpMinimizer_map_isometry
#print axioms PaperN.PartII.bestApproximationCoordinatePair_comap

#print axioms PaperN.PartII.orthonormal_continuousFamily_comap
#print axioms PaperN.PartII.subspaceCoordinateClass_comap

#print axioms PaperN.PartII.distanceToContinuous_toL2_integral
#print axioms PaperN.PartII.distanceToContinuous_toL2_comap
#print axioms PaperN.PartII.continuousEigenfunction_comap
#print axioms PaperN.PartII.spectralCutoff_comap_mem

#print axioms PaperN.PartII.probability_map_isometryEquiv_symm
#print axioms PaperN.PartII.spectralCutoffPullbackEquiv
#print axioms PaperN.PartII.spectralCutoff_finrank_eq_of_isometryEquiv
#print axioms PaperN.PartII.AmbientKernel.selectedSpectralCoordinateClass_comap

#print axioms PaperN.PartII.zeroCoordinatePair
#print axioms PaperN.PartII.zeroCoordinatePair_comap
#print axioms PaperN.PartII.zeroCoordinatePair_value
#print axioms PaperN.PartII.zeroCoordinatePair_pseudometric
#print axioms PaperN.PartII.zeroCoordinatePair_unitNormError
#print axioms PaperN.PartII.zeroCoordinatePair_coordinateError
#print axioms PaperN.PartII.zeroCoordinatePair_metric_error
#print axioms PaperN.PartII.zeroCoordinatePair_metric_error_lt

#print axioms PaperN.PartII.diameter_sub_le_distortion
#print axioms PaperN.PartII.diameter_tendsto_of_distortion
#print axioms PaperN.PartII.diameter_tendsto_of_commonRealization

#print axioms PaperN.PartII.ghDiameter
#print axioms PaperN.PartII.ghDiameter_toGHSpace
#print axioms PaperN.PartII.continuous_ghDiameter
#print axioms PaperN.PartII.singletonModelDomain
#print axioms PaperN.PartII.isOpen_singletonModelDomain
#print axioms PaperN.PartII.singleton_mem_singletonModelDomain
#print axioms PaperN.PartII.zeroCoordinatePair_error_on_singletonModelDomain
#print axioms PaperN.PartII.singletonModelDomain_mem_nhds
#print axioms PaperN.PartII.zeroCoordinatePair_metric_error_eq_ghDiameter

#print axioms PaperN.PartII.zeroCoordinateClass
#print axioms PaperN.PartII.zeroCoordinateClass_comap
#print axioms PaperN.PartII.zeroCoordinateClass_representative
#print axioms PaperN.PartII.zeroCoordinateClass_equivariance
#print axioms PaperN.PartII.zeroCoordinateClass_pseudometric
#print axioms PaperN.PartII.zeroCoordinateClass_bound
#print axioms PaperN.PartII.zeroCoordinateClass_metric_error
#print axioms PaperN.PartII.zeroCoordinateClass_representatives_converge

#print axioms PaperN.PartII.LocalModel
#print axioms PaperN.PartII.LocalModel.pseudometric_invariant
#print axioms PaperN.PartII.singletonLocalModel
#print axioms PaperN.PartII.exists_localModel_of_subsingleton

#print axioms PaperN.PartII.coordinate_equivariance_of_comap_eq
#print axioms PaperN.PartII.coordinate_metric_error_eq_of_comap_eq
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.coordinateClass_comap
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.representative_equivariance

#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.ghError
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.ghError_toGHSpace
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.ghError_nonneg
#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.continuous_ghError

#print axioms PaperN.PartII.AmbientKernel.SpectralModelNeighborhood.toLocalModel
#print axioms PaperN.PartII.AmbientKernel.exists_localModel_of_strictConvex

#print axioms PaperN.PartII.abs_midpoint_rpow_le
#print axioms PaperN.PartII.abs_midpoint_rpow_lt
#print axioms PaperN.PartII.abs_midpoint_rpow_eq_iff
#print axioms PaperN.PartII.integral_abs_midpoint_rpow_eq_iff

#print axioms PaperN.PartII.lp_norm_rpow_eq_integral
#print axioms PaperN.PartII.lp_strictConvexSpace
#print axioms PaperN.PartII.AmbientKernel.exists_localModel

#print axioms PaperN.PartII.LocalModel.restrict
#print axioms PaperN.PartII.LocalModel.shrink
#print axioms PaperN.PartII.LocalModel.shrink_error_lt
#print axioms PaperN.PartII.LocalModel.shrink_representative_error_lt
#print axioms PaperN.PartII.AmbientKernel.exists_uniformly_approximating_localModel

#print axioms PaperN.PartII.pseudometric_gh_eq_of_equiv
#print axioms PaperN.PartII.ofMetric_gh
#print axioms PaperN.PartII.LocalModel.ghMap
#print axioms PaperN.PartII.LocalModel.ghMap_eq
#print axioms PaperN.PartII.LocalModel.ghMap_dist_le

#print axioms PaperN.PartII.coordinate_gh_tendsto
#print axioms PaperN.PartII.LocalModel.continuous_ghMap
#print axioms PaperN.PartII.AmbientKernel.exists_continuous_local_approximation

#print axioms PaperN.PartII.CoordinateNormCarrier
#print axioms PaperN.PartII.CoordinateNormCarrier.norm_eq
#print axioms PaperN.PartII.CoordinateNormCarrier.linearEquiv
#print axioms PaperN.PartII.CoordinateNormCarrier.continuousLinearEquiv
#print axioms PaperN.PartII.NormedCoordinatePair.normedCoordinates
#print axioms PaperN.PartII.NormedCoordinatePair.dist_normedCoordinates
#print axioms PaperN.PartII.NormedCoordinatePair.normedImage
#print axioms PaperN.PartII.NormedCoordinatePair.quotient_isometry_normedImage

#print axioms PaperN.PartII.coordinateDualFunctional
#print axioms PaperN.PartII.coordinateDualFunctional_apply
#print axioms PaperN.PartII.coordinateDualNorm
#print axioms PaperN.PartII.continuous_coordinateDualNorm
#print axioms PaperN.PartII.coordinateDualNorm_pos
#print axioms PaperN.PartII.abs_inner_le_coordinateDualNorm_mul
#print axioms PaperN.PartII.coordinateDualNorm_eq_sSup
#print axioms PaperN.PartII.coordinateDualEmbedding

#print axioms PaperN.PartII.coordinateDualFunctional_surjective
#print axioms PaperN.PartII.exists_coordinateDual_norming
#print axioms PaperN.PartII.coordinateDualEmbeddingLinear
#print axioms PaperN.PartII.coordinateDualEmbedding_norm_le
#print axioms PaperN.PartII.coordinateDualEmbedding_norm_eq
#print axioms PaperN.PartII.coordinateDualLinearIsometry
#print axioms PaperN.PartII.coordinateDualEmbedding_norm_sub

#print axioms PaperN.PartII.coordinateDualNorm_orthogonal
#print axioms PaperN.PartII.orthogonalSphereEquiv
#print axioms PaperN.PartII.orthogonalSpherePullback
#print axioms PaperN.PartII.orthogonalSphereAction
#print axioms PaperN.PartII.coordinateDualEmbedding_equivariant
#print axioms PaperN.PartII.orthogonalSphereAction_refl
#print axioms PaperN.PartII.orthogonalSphereAction_trans
#print axioms PaperN.PartII.orthogonalSphereAction_surjective
#print axioms PaperN.PartII.orthogonalSphereActionEquiv

#print axioms PaperN.PartII.continuous_orthogonal_inverse
#print axioms PaperN.PartII.continuous_orthogonalSphereAction
#print axioms PaperN.PartII.orthogonalOperatorTopology
#print axioms PaperN.PartII.continuous_orthogonalSphereAction_operatorTopology

#print axioms PaperN.PartII.coordinateDualNorm_le_mul_of_le
#print axioms PaperN.PartII.coordinateDualNorm_inv_bounds
#print axioms PaperN.PartII.coordinateDualNorm_inv_error
#print axioms PaperN.PartII.coordinateDualEmbedding_sub_norm_le

#print axioms PaperN.PartII.exists_norm_le_coordinateNorm
#print axioms PaperN.PartII.coordinateNorm_relative_of_sphere_error
#print axioms PaperN.PartII.coordinateDualEmbedding_tendsto_of_sphere_error
#print axioms PaperN.PartII.coordinateDualEmbedding_tendsto
#print axioms PaperN.PartII.coordinateDualEmbedding_uniformOn_ball_of_sphere_error
#print axioms PaperN.PartII.coordinateDualEmbedding_uniformOn_ball

#print axioms PaperN.PartII.LocalModel.shrinkBelow
#print axioms PaperN.PartII.LocalModel.shrinkBelow_error_lt
#print axioms PaperN.PartII.AmbientKernel.exists_variable_error_localModel
#print axioms PaperN.PartII.AmbientKernel.exists_variable_error_model_cover

#print axioms PaperN.PartII.exists_countable_subordinate_partition
#print axioms PaperN.PartII.partition_finite_common_neighborhood
#print axioms PaperN.PartII.AmbientKernel.exists_localModel_partition

#print axioms PaperN.PartII.blockSum_norm
#print axioms PaperN.PartII.blockSum_mem
#print axioms PaperN.PartII.blockSumAction
#print axioms PaperN.PartII.blockSumAction_surjective
#print axioms PaperN.PartII.blockSumAction_refl
#print axioms PaperN.PartII.blockSumAction_trans
#print axioms PaperN.PartII.blockSumActionEquiv
#print axioms PaperN.PartII.SphereBlockSum
#print axioms PaperN.PartII.sphereBlockSum_complete
#print axioms PaperN.PartII.sphereBlockSumAction

#print axioms PaperN.PartII.continuous_blockSum_finite
#print axioms PaperN.PartII.dense_blockSum_finite
#print axioms PaperN.PartII.blockSum_separable
#print axioms PaperN.PartII.sphereBlockSum_separable

#print axioms PaperN.PartII.blockSumAction_single
#print axioms PaperN.PartII.blockSum_tail_norm
#print axioms PaperN.PartII.blockSumAction_difference_le

#print axioms PaperN.PartII.continuous_blockSumAction_orbit
#print axioms PaperN.PartII.continuous_blockSumAction
#print axioms PaperN.PartII.continuous_sphereBlockSumAction
#print axioms PaperN.PartII.continuous_sphereBlockSumAction_product

#print axioms PaperN.PartII.isCompact_normPreservingOperators
#print axioms PaperN.PartII.range_orthogonalOperators
#print axioms PaperN.PartII.orthogonalOperator_compactSpace
#print axioms PaperN.PartII.orthogonalProduct_compactSpace

#print axioms PaperN.PartII.continuous_orthogonal_mul
#print axioms PaperN.PartII.continuous_orthogonal_inv
#print axioms PaperN.PartII.orthogonalOperator_isTopologicalGroup
#print axioms PaperN.PartII.orthogonalProduct_isTopologicalGroup

#print axioms PaperN.PartII.compactSetIsometry
#print axioms PaperN.PartII.compactSetIsometry_dist
#print axioms PaperN.PartII.continuous_compactSetIsometry
#print axioms PaperN.PartII.continuous_sphereCompactAction
#print axioms PaperN.PartII.isCompact_sphereCompactOrbit

#print axioms PaperN.PartII.compactOrbitDist
#print axioms PaperN.PartII.compactOrbitDist_attained
#print axioms PaperN.PartII.compactOrbitDist_nonneg
#print axioms PaperN.PartII.compactOrbitDist_le
#print axioms PaperN.PartII.compactOrbitDist_eq_zero_iff
#print axioms PaperN.PartII.compactOrbitDist_symm
#print axioms PaperN.PartII.compactOrbitDist_triangle

#print axioms PaperN.PartII.compactOrbitSetoid
#print axioms PaperN.PartII.compactOrbitDist_congr
#print axioms PaperN.PartII.CompactOrbitQuotient
#print axioms PaperN.PartII.compactOrbitQuotientMetric
#print axioms PaperN.PartII.compactOrbitQuotient_dist
#print axioms PaperN.PartII.compactOrbitQuotient_eq_iff
#print axioms PaperN.PartII.compactOrbitQuotient_lipschitz

#print axioms PaperN.PartII.compactOrbitQuotient_image_ball
#print axioms PaperN.PartII.compactOrbitQuotient_isOpenMap
#print axioms PaperN.PartII.compactOrbitQuotient_isQuotientMap
#print axioms PaperN.PartII.compactOrbitQuotient_topology_eq

#print axioms PaperN.PartII.sphereBlockSumAction_one
#print axioms PaperN.PartII.sphereBlockSumAction_mul
#print axioms PaperN.PartII.compactSetIsometry_refl
#print axioms PaperN.PartII.compactSetIsometry_trans
#print axioms PaperN.PartII.sphereBlockRepresentation
#print axioms PaperN.PartII.sphereCompactMulAction

#print axioms PaperN.PartII.SphereOrbit.GroupType
#print axioms PaperN.PartII.SphereOrbit.continuousSMul
#print axioms PaperN.PartII.SphereOrbit.isIsometricSMul
#print axioms PaperN.PartII.SphereOrbit.Space
#print axioms PaperN.PartII.SphereOrbit.metricSpace
#print axioms PaperN.PartII.SphereOrbit.projection
#print axioms PaperN.PartII.SphereOrbit.projection_lipschitz
#print axioms PaperN.PartII.SphereOrbit.projection_isQuotientMap
#print axioms PaperN.PartII.SphereOrbit.projection_eq_iff
#print axioms PaperN.PartII.SphereOrbit.dist_projection
#print axioms PaperN.PartII.SphereOrbit.separableSpace

#print axioms PaperN.PartII.compactSetIsometry_toGHSpace
#print axioms PaperN.PartII.SphereOrbit.realization
#print axioms PaperN.PartII.SphereOrbit.realization_projection
#print axioms PaperN.PartII.SphereOrbit.realization_lipschitz

#print axioms PaperN.PartII.finiteBlockFeature
#print axioms PaperN.PartII.finiteBlockFeature_norm
#print axioms PaperN.PartII.finiteBlockFeature_dist
#print axioms PaperN.PartII.finiteBlockFeature_equivariant
#print axioms PaperN.PartII.continuous_finiteBlockFeature
#print axioms PaperN.PartII.finiteDualFeature_dist

#print axioms PaperN.PartII.continuous_finiteBlockFeature_variable
#print axioms PaperN.PartII.finiteBlockFeature_eq_of_subset

#print axioms PaperN.PartII.weightedPseudometric
#print axioms PaperN.PartII.weightedPseudometric_apply
#print axioms PaperN.PartII.weightedPseudometric_error_le
#print axioms PaperN.PartII.weightedPseudometric_error_lt
#print axioms PaperN.PartII.weightedPseudometric_ghDist_le
#print axioms PaperN.PartII.weightedPseudometric_ghDist_lt
#print axioms PaperN.PartII.finiteBlockFeature_dist_eq_weighted

#print axioms PaperN.PartII.featureImage
#print axioms PaperN.PartII.featureImage_gh_eq
#print axioms PaperN.PartII.featureImage_quotient_isometry
#print axioms PaperN.PartII.finiteFeatureImage
#print axioms PaperN.PartII.finiteFeatureImage_gh_eq
#print axioms PaperN.PartII.finiteFeatureImage_ghDist_lt

#print axioms PaperN.PartII.featureImage_transport
#print axioms PaperN.PartII.finiteFeatureImage_transport
#print axioms PaperN.PartII.sphereFeatureImage_orbit_eq

#print axioms PaperN.PartII.NormedCoordinatePair.dualFeature
#print axioms PaperN.PartII.NormedCoordinatePair.dualFeature_dist
#print axioms PaperN.PartII.NormedCoordinatePair.dualFeature_norm
#print axioms PaperN.PartII.NormedCoordinatePair.dualFeature_equivariant
#print axioms PaperN.PartII.LocalModel.dualFeature_equivariance
#print axioms PaperN.PartII.LocalModel.dualFeature_bound

#print axioms PaperN.PartII.LocalModel.chosenPair
#print axioms PaperN.PartII.LocalModel.chosenPair_class
#print axioms PaperN.PartII.modelFeatureImage
#print axioms PaperN.PartII.modelFeature_active_mem
#print axioms PaperN.PartII.modelFeature_norm_le
#print axioms PaperN.PartII.modelFeatureImage_ghDist_lt
#print axioms PaperN.PartII.modelApproximation
#print axioms PaperN.PartII.modelApproximation_realization_dist_lt

#print axioms PaperN.PartII.modelFeatureImage_orbit_eq
#print axioms PaperN.PartII.modelApproximation_eq_image

#print axioms PaperN.PartII.finiteFeatureImage_eq_of_subset
#print axioms PaperN.PartII.modelApproximation_eq_representatives
#print axioms PaperN.PartII.modelApproximation_eq_representatives_on_superset

#print axioms PaperN.PartII.featureImage_dist_le
#print axioms PaperN.PartII.finiteBlockFeature_dist_le_variable
#print axioms PaperN.PartII.finiteFeatureImage_dist_le
#print axioms PaperN.PartII.finiteFeatureImage_tendsto

#print axioms PaperN.PartII.coordinateError_bddAbove
#print axioms PaperN.PartII.coordinateError_apply_le
#print axioms PaperN.PartII.coordinateError_nonneg
#print axioms PaperN.PartII.dualFeature_error_le
#print axioms PaperN.PartII.dualFeature_error_tendsto

#print axioms PaperN.PartII.finiteDualFeatureImage_tendsto
#print axioms PaperN.PartII.modelApproximation_tendsto_of_representatives
#print axioms PaperN.PartII.modelApproximation_tendsto_on_common_domains
#print axioms PaperN.PartII.continuous_modelApproximation

#print axioms PaperN.PartII.AmbientKernel.exists_continuous_orbit_approximation

#print axioms PaperN.PartII.uniform_metric_error_isometry
#print axioms PaperN.PartII.modelPseudometric
#print axioms PaperN.PartII.modelPseudometric_equivariant
#print axioms PaperN.PartII.modelUniformError
#print axioms PaperN.PartII.modelUniformError_invariant
#print axioms PaperN.PartII.modelError
#print axioms PaperN.PartII.modelError_eq
#print axioms PaperN.PartII.modelError_lt
#print axioms PaperN.PartII.modelFeatureImage_gh_eq
#print axioms PaperN.PartII.modelError_nonneg
#print axioms PaperN.PartII.modelApproximation_dist_le_error

#print axioms PaperN.PartII.feature_pseudometric_error_le
#print axioms PaperN.PartII.feature_uniform_error_comparison
#print axioms PaperN.PartII.feature_uniform_error_tendsto
#print axioms PaperN.PartII.modelPseudometric_eq_representative_feature

#print axioms PaperN.PartII.modelError_tendsto_of_representatives
#print axioms PaperN.PartII.modelError_tendsto_on_common_domains
#print axioms PaperN.PartII.continuous_modelError

#print axioms PaperN.PartII.blend_kernel_sub_norm
#print axioms PaperN.PartII.blend_gh_dist_le
#print axioms PaperN.PartII.modelInterpolation
#print axioms PaperN.PartII.modelInterpolation_eq
#print axioms PaperN.PartII.modelInterpolation_zero
#print axioms PaperN.PartII.modelInterpolation_one
#print axioms PaperN.PartII.modelInterpolation_track_le
#print axioms PaperN.PartII.modelInterpolation_track_lipschitz

#print axioms PaperN.PartII.modelInterpolation_tendsto_of_representatives
#print axioms PaperN.PartII.modelInterpolation_tendsto_on_common_domains
#print axioms PaperN.PartII.continuous_modelInterpolation_fixed
#print axioms PaperN.PartII.continuous_modelInterpolation

#print axioms PaperN.Shared.ContinuousPseudometric.blend_ofMetric_lower
#print axioms PaperN.Shared.ContinuousPseudometric.blend_ofMetric_eq_zero_iff
#print axioms PaperN.Shared.ContinuousPseudometric.blendOfMetricHomeomorph
#print axioms PaperN.Shared.ContinuousPseudometric.blendOfMetricHomeomorph_dist
#print axioms PaperN.PartII.modelInterpolation_compatible

#print axioms PaperN.PartII.orthogonalOperator_secondCountable
#print axioms PaperN.PartII.orthogonalProduct_secondCountable

#print axioms PaperN.PartII.normedSpace_connected
#print axioms PaperN.PartII.ball_contains_continuum
#print axioms PaperN.PartII.normedSpace_local_continua
#print axioms PaperN.PartII.sphereBlockSum_local_continua

#print axioms PaperN.PartII.IsAbsoluteRetract
#print axioms PaperN.PartII.IsEquivariantAbsoluteRetract
#print axioms PaperN.PartII.IsAbsoluteRetract.of_homeomorph
#print axioms PaperN.PartII.isAbsoluteRetract_homeomorph_iff

#print axioms PaperN.PartII.HasContinuumConnectedBasis
#print axioms PaperN.PartII.normedSpace_continuumConnectedBasis
#print axioms PaperN.PartII.EquivariantHyperspaceARInput
#print axioms PaperN.PartII.OrbitARInput
#print axioms PaperN.PartII.orthogonalOperator_t2Space
#print axioms PaperN.PartII.SphereOrbit.hyperspace_equivariantAR
#print axioms PaperN.PartII.SphereOrbit.absoluteRetract

#print axioms PaperN.PartII.modelInterpolation_track_lt
#print axioms PaperN.PartII.modelInterpolation_track_diam_le
#print axioms PaperN.PartII.AmbientKernel.exists_AR_domination

#print axioms PaperN.PartII.IsAbsoluteNeighborhoodRetract
#print axioms PaperN.PartII.IsSeparableAbsoluteNeighborhoodRetract
#print axioms PaperN.PartII.IsAbsoluteRetract.isAbsoluteNeighborhoodRetract
#print axioms PaperN.PartII.IsAbsoluteNeighborhoodRetract.separable
#print axioms PaperN.PartII.HasSmallANRDomination
#print axioms PaperN.PartII.HannerDominationInput
#print axioms PaperN.PartII.HannerANRCategoryInput
#print axioms PaperN.PartII.AmbientKernel.ghSpace_hasSmallANRDomination
#print axioms PaperN.PartII.AmbientKernel.ghSpace_absoluteNeighborhoodRetract

#print axioms PaperN.PartII.IsAbsoluteExtensor
#print axioms PaperN.PartII.IsAbsoluteNeighborhoodExtensor
#print axioms PaperN.PartII.IsAbsoluteExtensor.isAbsoluteRetract
#print axioms PaperN.PartII.IsAbsoluteNeighborhoodExtensor.isAbsoluteNeighborhoodRetract
#print axioms PaperN.PartII.ANRToANEInput
#print axioms PaperN.PartII.ContractibleANEToAEInput
#print axioms PaperN.PartII.AmbientKernel.ghSpace_absoluteExtensor
#print axioms PaperN.PartII.AmbientKernel.ghSpace_absoluteRetract

#print axioms PaperN.PartIV.productCorrespondence
#print axioms PaperN.PartIV.productCorrespondence_distortionLE
#print axioms PaperN.PartIV.ghDist_prod_le
#print axioms PaperN.PartIV.productGH
#print axioms PaperN.PartIV.productGH_dist_le
#print axioms PaperN.PartIV.productGH_lipschitz
#print axioms PaperN.PartIV.productGH_toGHSpace

#print axioms PaperN.PartIV.Equilateral
#print axioms PaperN.PartIV.equilateralMetric
#print axioms PaperN.PartIV.equilateral_dist
#print axioms PaperN.PartIV.equilateral_ghDist_le
#print axioms PaperN.PartIV.equilateralProduct
#print axioms PaperN.PartIV.equilateralProduct_error
#print axioms PaperN.PartIV.equilateralProduct_dist_le
#print axioms PaperN.PartIV.equilateralProduct_lipschitz
#print axioms PaperN.PartIV.equilateralProduct_fiber_dist

#print axioms PaperN.PartIV.coverClearance
#print axioms PaperN.PartIV.coverClearance_bounds
#print axioms PaperN.PartIV.coverClearance_lipschitz
#print axioms PaperN.PartIV.coverClearance_pos
#print axioms PaperN.PartIV.mem_of_dist_lt_coverClearance
#print axioms PaperN.PartIV.coverScale
#print axioms PaperN.PartIV.coverClearance_bddAbove
#print axioms PaperN.PartIV.coverScale_pos_le
#print axioms PaperN.PartIV.coverScale_lipschitz
#print axioms PaperN.PartIV.coverScale_subordinate
#print axioms PaperN.PartIV.positiveCoverScale
#print axioms PaperN.PartIV.positiveCoverScale_lipschitz
#print axioms PaperN.PartIV.coverProduct
#print axioms PaperN.PartIV.coverProduct_lipschitz
#print axioms PaperN.PartIV.coverProduct_close

#print axioms PaperN.PartIV.separated_range_card
#print axioms PaperN.PartIV.packing_forces_ghDist
#print axioms PaperN.PartIV.equilateralProduct_rep_fiber
#print axioms PaperN.PartIV.equilateralProduct_rep_packing
#print axioms PaperN.PartIV.equilateralProduct_separated_from_packing

#print axioms PaperN.PartIV.compactFamily_packing_bound
#print axioms PaperN.PartIV.compactFamily_avoided_by_products
#print axioms PaperN.PartIV.compactDomain_product_step

#print axioms PaperN.PartIV.cardApprox
#print axioms PaperN.PartIV.cardApprox_continuous
#print axioms PaperN.PartIV.exists_next_cardinality
#print axioms PaperN.PartIV.exists_recursive_cardinalities
#print axioms PaperN.PartIV.exists_disjoint_product_approximations

#print axioms PaperN.PartIV.cardApprox_scale_lower
#print axioms PaperN.PartIV.cardApprox_local_card_bound
#print axioms PaperN.PartIV.cardApprox_locallyFinite

#print axioms PaperN.PartIV.IsDiscreteFamily
#print axioms PaperN.PartIV.isDiscreteFamily_of_locallyFinite
#print axioms PaperN.PartIV.exists_discrete_approximations

#print axioms PaperN.PartIV.HilbertCube
#print axioms PaperN.PartIV.HasHilbertCubeDiscreteApproximation
#print axioms PaperN.PartIV.image_index_slice
#print axioms PaperN.PartIV.ghSpace_hilbertCubeDiscreteApproximation

#print axioms PaperN.PartIV.RealHilbertSpace
#print axioms PaperN.PartIV.TorunczykRecognitionInput
#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert_of_absoluteRetract
#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert

#print axioms PaperN.PartIV.ghDiameter
#print axioms PaperN.PartIV.ghDiameter_toGHSpace
#print axioms PaperN.PartIV.diameter_le_of_distortion
#print axioms PaperN.PartIV.ghDiameter_lipschitz
#print axioms PaperN.PartIV.diam_prod_eq_one
#print axioms PaperN.PartIV.cardApprox_diameter_one

#print axioms PaperN.PartIV.UnitDiameterSpace
#print axioms PaperN.PartIV.instMetricSpaceUnitDiameterSpace
#print axioms PaperN.PartIV.unitDiameter_isClosed
#print axioms PaperN.PartIV.instCompleteSpaceUnitDiameterSpace
#print axioms PaperN.PartIV.closed_subspace_cover
#print axioms PaperN.PartIV.isDiscreteFamily_subtype_ranges
#print axioms PaperN.PartIV.unitDiameter_hilbertCubeDiscreteApproximation

#print axioms PaperN.PartIV.ghDiameter_scaledGH
#print axioms PaperN.PartIV.ghDiameter_scaleGH
#print axioms PaperN.PartIV.positiveDiameter_isOpen
#print axioms PaperN.PartIV.diameterNormalize
#print axioms PaperN.PartIV.diameterNormalize_continuous
#print axioms PaperN.PartIV.diameterNormalize_retract

#print axioms PaperN.PartIV.diam_univ_prod
#print axioms PaperN.PartIV.ghDiameter_productGH
#print axioms PaperN.PartIV.productGH_point_right
#print axioms PaperN.PartIV.productGH_point_left
#print axioms PaperN.PartIV.unitDiameter_nonempty
#print axioms PaperN.PartIV.unitDiameter_product_positive
#print axioms PaperN.PartIV.unitDiameterContraction
#print axioms PaperN.PartIV.unitDiameterContraction_continuous
#print axioms PaperN.PartIV.unitDiameterContraction_zero
#print axioms PaperN.PartIV.unitDiameterContraction_one
#print axioms PaperN.PartIV.unitDiameter_contractible

#print axioms PaperN.PartIV.ane_of_open_retract
#print axioms PaperN.PartIV.unitDiameter_absoluteNeighborhoodExtensor
#print axioms PaperN.PartIV.unitDiameter_absoluteExtensor
#print axioms PaperN.PartIV.unitDiameter_absoluteRetract
#print axioms PaperN.PartIV.unitDiameter_homeomorphic_hilbert_of_absoluteExtensor
#print axioms PaperN.PartIV.unitDiameter_homeomorphic_hilbert

#print axioms PaperN.PartIV.HasStrongLocalContractions
#print axioms PaperN.PartIV.strongLocalContractions_of_homeomorph
#print axioms PaperN.PartIV.ghSpace_strongLocalContractions_of_homeomorph
#print axioms PaperN.PartIV.ghSpace_strongLocalContractions

#print axioms PaperN.PartIV.KadetsHomeomorphismInput
#print axioms PaperN.PartIV.ghSpace_homeomorphic_banach_of_homeomorph
#print axioms PaperN.PartIV.ghSpace_homeomorphic_banach

#print axioms PaperN.PartIV.RealSequenceSpace
#print axioms PaperN.PartIV.realSequence_units_independent
#print axioms PaperN.PartIV.realSequence_not_finiteDimensional
#print axioms PaperN.PartIV.realSequence_separable
#print axioms PaperN.PartIV.ghSpace_homeomorphic_realSequence
#print axioms PaperN.PartIV.realHilbert_separable
#print axioms PaperN.PartIV.realHilbert_not_finiteDimensional

#print axioms PaperN.PartIV.IntervalFunctionSpace
#print axioms PaperN.PartIV.interval_polynomial_injective
#print axioms PaperN.PartIV.interval_monomials_independent
#print axioms PaperN.PartIV.intervalFunction_not_finiteDimensional
#print axioms PaperN.PartIV.intervalFunction_separable
#print axioms PaperN.PartIV.intervalFunction_complete
#print axioms PaperN.PartIV.ghSpace_homeomorphic_intervalFunctions

#print axioms PaperN.PartI.isClosed_invariantProbabilities
#print axioms PaperN.PartI.barycenter_invariant_of_mass_one

#print axioms PaperN.PartI.CurrentBarycenterStatement
#print axioms PaperN.PartI.currentBarycenter_spec
#print axioms PaperN.PartI.CurrentInvariantAssignmentStatement
#print axioms PaperN.PartI.currentInvariantAssignment_spec

#print axioms PaperN.PartI.TotallyAnisometric
#print axioms PaperN.PartI.isometry_eq_id_of_totallyAnisometric
#print axioms PaperN.PartI.isometry_eq_id_of_infinite_totallyAnisometric
#print axioms PaperN.PartI.subsingleton_isometryEquiv_of_infinite_totallyAnisometric
#print axioms PaperN.PartI.not_continuousAt_of_dense_constant

#print axioms PaperN.PartI.isometryGroupConjugacy
#print axioms PaperN.PartI.isometryGroupGH
#print axioms PaperN.PartI.isometryGroupGH_toGHSpace
#print axioms PaperN.PartI.isometryGroupGH_eq_point_iff
#print axioms PaperN.PartI.isometryGroupGH_not_continuousAt
#print axioms PaperN.PartI.infinite_of_perfect_metric
#print axioms PaperN.PartI.RouyerGenericInput
#print axioms PaperN.PartI.dense_rigid_of_rouyer
#print axioms PaperN.PartI.isometryGroupGH_discontinuous_of_rouyer

#print axioms PaperN.PartI.equilateralPermutation
#print axioms PaperN.PartI.twoPoint_isometryGroup_nontrivial
#print axioms PaperN.PartI.isometryGroupGH_not_continuousAt_concrete
#print axioms PaperN.PartI.isometryGroupGH_not_continuous

#print axioms PaperN.PartIII.CurtisSchoriHyperspaceInput
#print axioms PaperN.PartIII.peano_closed_iff_compact
#print axioms PaperN.PartIII.peano_hyperspace_dist
#print axioms PaperN.PartIII.peano_hyperspace_homeomorphic_cube

#print axioms PaperN.PartII.spectralIsometryAction
#print axioms PaperN.PartII.spectralIsometryAction_apply
#print axioms PaperN.PartII.continuous_spectralIsometryAction_orbit
#print axioms PaperN.PartII.spectralIsometryAction_integral_mul
#print axioms PaperN.PartII.continuous_spectralIsometryAction_coefficient
#print axioms PaperN.PartII.selectedSpectralIsometryAction

#print axioms PaperN.PartII.spectralIsometryMatrix
#print axioms PaperN.PartII.spectralIsometryMatrix_apply
#print axioms PaperN.PartII.spectralIsometryMatrix_one
#print axioms PaperN.PartII.spectralIsometryMatrix_mul
#print axioms PaperN.PartII.spectralIsometryMatrixHom
#print axioms PaperN.PartII.continuous_spectralIsometryMatrix
#print axioms PaperN.PartII.spectralIsometryMatrix_inv_mul
#print axioms PaperN.PartII.spectralIsometryMatrix_basis_expansion

#print axioms PaperN.PartII.SpectralBasisIntegralOrthonormal
#print axioms PaperN.PartII.spectralBasis_coefficient_integral
#print axioms PaperN.PartII.spectralIsometryMatrix_integral
#print axioms PaperN.PartII.spectralIsometryMatrix_inverse_transpose
#print axioms PaperN.PartII.spectralIsometryMatrix_orthogonal
#print axioms PaperN.PartII.spectralIsometryMatrix_direct_basis_expansion
#print axioms PaperN.PartII.spectralOrthogonalRepresentation
#print axioms PaperN.PartII.continuous_spectralOrthogonalRepresentation

#print axioms PaperN.PartII.spectralBasis_integralOrthonormal_of_L2
#print axioms PaperN.PartII.chosenSpectralBasis_integralOrthonormal
#print axioms PaperN.PartII.chosenSpectralRepresentation
#print axioms PaperN.PartII.continuous_chosenSpectralRepresentation
#print axioms PaperN.PartII.AmbientKernel.selected_exists_orthogonalRepresentation

#print axioms PaperN.PartII.spectral_coordinateSynthesis
#print axioms PaperN.PartII.spectral_coordinateLpNorm

#print axioms PaperN.PartII.spectral_matrix_surjective

#print axioms PaperN.PartII.spectral_distanceObjective

#print axioms PaperN.PartII.spectral_coordinateLpMinimizer

#print axioms PaperN.PartII.spectral_bestApproximationCoordinates

#print axioms PaperN.PartII.spectralBasisTransition

#print axioms PaperN.PartII.spectralBasisTransition_inverse

#print axioms PaperN.PartII.spectralIsometryMatrix_conjugacy

#print axioms PaperN.PartII.spectral_coordinateChange_intertwines

#print axioms PaperN.PartII.spectral_coordinateChange_conjugacy

#print axioms PaperN.PartII.spectral_orthonormalCoordinateChange_conjugacy

#print axioms PaperN.PartII.AmbientKernel.selected_spectral_equivariant_representative
#print axioms PaperN.PartII.zeroCoordinateClass_equivariant_representative

#print axioms PaperN.PartIV.UrysohnFunction.ext

#print axioms PaperN.PartIV.UrysohnFunction.finite_disagreement_tail

#print axioms PaperN.PartIV.UrysohnFunction.exists_greatest_disagreement

#print axioms PaperN.PartIV.UrysohnFunction.distance

#print axioms PaperN.PartIV.UrysohnFunction.distance_self

#print axioms PaperN.PartIV.UrysohnFunction.distance_spec

#print axioms PaperN.PartIV.UrysohnFunction.le_distance

#print axioms PaperN.PartIV.UrysohnFunction.distance_le

#print axioms PaperN.PartIV.UrysohnFunction.distance_comm

#print axioms PaperN.PartIV.UrysohnFunction.distance_eq_zero_iff

#print axioms PaperN.PartIV.UrysohnFunction.distance_ultrametric

#print axioms PaperN.PartIV.UrysohnFunction.metricSpace

#print axioms PaperN.PartIV.UrysohnFunction.dist_eq

#print axioms PaperN.PartIV.UrysohnFunction.isUltrametricDist

#print axioms PaperN.PartIV.UrysohnFunction.distance_le_iff

#print axioms PaperN.PartIV.UrysohnFunction.distance_lt_iff

#print axioms PaperN.PartIV.UrysohnFunction.mem_ball_iff

#print axioms PaperN.PartIV.ultrametric_of_isometry

#print axioms PaperN.PartIV.ultrametric_iff_isometryEquiv

#print axioms PaperN.PartIV.UltrametricGH

#print axioms PaperN.PartIV.UltrametricGH.ext

#print axioms PaperN.PartIV.ultrametric_toGHSpace_iff

#print axioms PaperN.PartIV.toUltrametricGH

#print axioms PaperN.PartIV.toUltrametricGH_eq_iff

#print axioms PaperN.PartIV.toUltrametricGH_rep

#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert_from_selection_inputs

#print axioms PaperN.PartII.distanceOperator_real_factorization

#print axioms PaperN.PartII.distanceOperator_compact_proved

#print axioms PaperN.PartII.realEmbed_inner

#print axioms PaperN.PartII.distanceOperator_selfAdjoint_proved

#print axioms PaperN.PartII.distanceKernelSpectralInput_proved

#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert_main

#print axioms PaperN.PartII.compact_selfAdjoint_finite_large_eigenvalues

#print axioms PaperN.PartII.compactEigenvalueFinitenessInput_proved

#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert_of_eigenvalue_finiteness

#print axioms PaperN.PartII.LocalModel.coordinateClass_comap

#print axioms PaperN.PartII.LocalModel.universalClass

#print axioms PaperN.PartII.LocalModel.universalClass_eq_comap

#print axioms PaperN.PartII.LocalModel.universalClass_bound

#print axioms PaperN.PartII.LocalModel.universalClass_comap

#print axioms PaperN.PartII.LocalModel.universalClass_equivariance

#print axioms PaperN.PartII.LocalModel.universalClass_error_eq

#print axioms PaperN.Shared.Correspondence.comapEquiv
#print axioms PaperN.Shared.Correspondence.comapEquivRel
#print axioms PaperN.Shared.Correspondence.iSup_comapEquiv
#print axioms PaperN.PartII.coordinateError_comapEquiv

#print axioms PaperN.PartII.LocalModel.universal_representatives_converge

#print axioms PaperN.PartII.LocalModel.universalClass_pseudometric_invariant
#print axioms PaperN.PartII.LocalModel.universalClass_representative_bound

#print axioms PaperN.PartII.IsAbsoluteRetract.retraction_of_small
#print axioms PaperN.PartII.IsAbsoluteNeighborhoodRetract.retraction_of_small
#print axioms PaperN.PartII.small_separable_metric
#print axioms PaperN.PartII.IsAbsoluteNeighborhoodRetract.separable_allUniverses

#print axioms PaperN.PartII.closedEmbedding_into_factor_range
#print axioms PaperN.PartII.IsAbsoluteRetract.retraction_of_factor

#print axioms PaperN.PartII.IsAbsoluteRetract.allUniverses
#print axioms PaperN.PartII.AmbientKernel.ghSpace_absoluteRetract_allUniverses
#print axioms PaperN.PartII.AmbientKernel.ghSpace_absoluteNeighborhoodRetract_allUniverses

#print axioms PaperN.PartII.IsSeparableAbsoluteNeighborhoodRetract.retraction_of_factor
#print axioms PaperN.PartII.IsSeparableAbsoluteNeighborhoodRetract.allUniverses
#print axioms PaperN.PartII.hannerANRCategoryInput_proved

#print axioms PaperN.PartII.IsAbsoluteNeighborhoodExtensor.of_contractible
#print axioms PaperN.PartII.contractibleANEToAEInput_proved

#print axioms PaperN.PartI.levyProkhorovDist_map_le_of_dist_le
#print axioms PaperN.PartI.levyProkhorovDist_map_tendsto_of_dist_le

#print axioms PaperN.PartI.exists_measurable_near_map
#print axioms PaperN.PartI.exists_measurable_map_of_hausdorffDist_lt
#print axioms PaperN.PartI.probabilityApproximationInput_proved

#print axioms PaperN.PartI.BasedAmbient.attach_hausdorffDist
#print axioms PaperN.PartI.BasedAmbient.towerStep_isometry
#print axioms PaperN.PartI.BasedAmbient.towerStep_base

#print axioms PaperN.PartI.BasedAmbient.jointBase_at
#print axioms PaperN.PartI.BasedAmbient.jointBase_isometry
#print axioms PaperN.PartI.BasedAmbient.jointMap_isometry
#print axioms PaperN.PartI.BasedAmbient.joint_hausdorffDist
#print axioms PaperN.PartI.BasedAmbient.joint_hausdorffConverges

#print axioms PaperN.PartI.ghCommonEmbeddingInput_proved

#print axioms PaperN.PartI.invariantFiberLawSelection_main
#print axioms PaperN.PartI.currentInvariantAssignment_main

#print axioms PaperN.PartII.collectivelyCompact_differences_norm_bound
#print axioms PaperN.PartII.strong_tendsto_apply_of_norm_bound

#print axioms PaperN.PartII.strong_eventually_uniform_on_compact
#print axioms PaperN.PartII.collectivelyCompact_difference_square_tendsto

#print axioms PaperN.PartII.isUnit_one_sub_of_square_norm_lt_one
#print axioms PaperN.PartII.collectivelyCompact_eventually_isUnit_one_sub
#print axioms PaperN.PartII.collectivelyCompact_eventually_isUnit

#print axioms PaperN.PartII.collectivelyCompact_eventually_mem_resolvent
#print axioms PaperN.PartII.collectivelyCompact_eventually_finite_resolvent

#print axioms PaperN.PartII.norm_le_one_sub_of_square_bound
#print axioms PaperN.PartII.collectivelyCompact_eventually_one_sub_lowerBound
#print axioms PaperN.PartII.tendsto_solutions_of_uniform_lowerBound

#print axioms PaperN.PartII.collectivelyCompact_eventually_lowerBound
#print axioms PaperN.PartII.collectivelyCompact_inverse_tendsto

#print axioms PaperN.PartII.inverse_norm_le_of_lowerBound
#print axioms PaperN.PartII.collectivelyCompact_eventually_inverse_norm_bound
#print axioms PaperN.PartII.collectivelyCompact_resolvent_tendsto

#print axioms PaperN.PartII.isUnit_and_inverse_norm_le_of_near

#print axioms PaperN.PartII.norm_shift_sub_le
#print axioms PaperN.PartII.resolvent_near_bound
#print axioms PaperN.PartII.collectivelyCompact_eventually_resolvent_neighborhood

#print axioms PaperN.PartII.collectivelyCompact_eventually_compact_resolvent_bound
#print axioms PaperN.PartII.collectivelyCompactSpectralInclusionInput_proved

#print axioms PaperN.PartII.inverse_apply_sub_norm_le
#print axioms PaperN.PartII.resolvent_apply_sub_norm_le
#print axioms PaperN.PartII.collectivelyCompact_resolvent_uniform_of_compact_image
#print axioms PaperN.PartII.collectivelyCompact_resolvent_uniform_on_compact

#print axioms PaperN.PartII.segmentResolvent_apply_sub_norm_le
#print axioms PaperN.PartII.collectivelyCompact_segmentResolvent_tendsto

#print axioms PaperN.PartII.collectivelyCompact_quadrilateralResolvent_tendsto
#print axioms PaperN.PartII.collectivelyCompact_rectangleResolvent_tendsto
#print axioms PaperN.PartII.collectivelyCompact_cutoffContourOperator_tendsto

#print axioms PaperN.PartII.eventually_injective_on_finite_subspace

#print axioms PaperN.PartII.projection_injective_on_range_of_square_norm_lt_one
#print axioms PaperN.PartII.projection_finite_rank_eq_of_square_norm_lt_one
#print axioms PaperN.PartII.collectivelyCompact_projection_rank_stable

#print axioms PaperN.PartII.segmentResolvent_norm_le
#print axioms PaperN.PartII.collectivelyCompact_segmentResolvent_eventually_norm_bound
#print axioms PaperN.PartII.collectivelyCompact_segmentResolvent_norm_bound

#print axioms PaperN.PartII.AmbientKernel.selectedCutoffProjection_strong

#print axioms PaperN.PartII.strong_compact_images_contained
#print axioms PaperN.PartII.collectivelyCompact_comp_of_strong

#print axioms PaperN.PartII.collectivelyCompact_comp_of_norm_bound
#print axioms PaperN.PartII.collectivelyCompact_sandwich

#print axioms PaperN.PartII.compact_probability_integral_container
#print axioms PaperN.PartII.compact_unit_interval_integral_container

#print axioms PaperN.PartII.collectivelyCompact_intervalIntegral
#print axioms PaperN.PartII.collectivelyCompact_segmentResolvent_difference

#print axioms PaperN.PartII.parameter_strong_uniform_on_compact
#print axioms PaperN.PartII.parameter_strong_compact_images_contained

#print axioms PaperN.PartII.collectivelyCompact_resolvent_compact_images
#print axioms PaperN.PartII.collectivelyCompact_resolvent_tail_compact_images

#print axioms PaperN.PartII.resolvent_apply_sub_eq
#print axioms PaperN.PartII.collectivelyCompact_bounded_images
#print axioms PaperN.PartII.collectivelyCompact_resolvent_difference_tail

#print axioms PaperN.PartII.collectivelyCompact_segmentResolvent_difference_tail

#print axioms PaperN.PartII.CollectivelyCompactTail.add
#print axioms PaperN.PartII.CollectivelyCompactTail.smul
#print axioms PaperN.PartII.collectivelyCompact_quadrilateral_difference_tail
#print axioms PaperN.PartII.collectivelyCompact_rectangle_difference_tail
#print axioms PaperN.PartII.collectivelyCompact_cutoffContour_difference_tail

#print axioms PaperN.PartII.collectivelyCompactTail_projection_rank_stable
#print axioms PaperN.PartII.collectivelyCompact_cutoffContour_rank_stable

#print axioms PaperN.PartII.AmbientKernel.selectedCutoffProjection_rank_proved

#print axioms PaperN.PartII.operator_apply_resolvent_eq
#print axioms PaperN.PartII.resolvent_apply_eq_scalar_add
#print axioms PaperN.PartII.weightedResolvent_circleIntegrable

#print axioms PaperN.PartII.map_circleIntegral
#print axioms PaperN.PartII.circleResolvent_factor
#print axioms PaperN.PartII.circleResolvent_range_le

#print axioms PaperN.PartII.cutoffCircle_disks_avoid_zero
#print axioms PaperN.PartII.cutoffCircle_range_le_operator_range
#print axioms PaperN.PartII.circleResolvent_isCompactOperator
#print axioms PaperN.PartII.cutoffCircle_isCompactOperator

#print axioms PaperN.PartII.finiteDimensional_of_compact_fixes_subspace
#print axioms PaperN.PartII.closedEigenSpan_cutoff_finiteDimensional
#print axioms PaperN.PartII.cutoffCircle_range_eq_eigenspaces

#print axioms PaperN.PartII.symmetric_apply_apply_eq_zero
#print axioms PaperN.PartII.factor_restriction_zero_on_square_range
#print axioms PaperN.PartII.AmbientKernel.restriction_zero_on_ambient_square_range

#print axioms PaperN.PartII.weightedCircleOperator_factor
#print axioms PaperN.PartII.circleResolvent_square_factor
#print axioms PaperN.PartII.circleResolvent_range_le_square_range
#print axioms PaperN.PartII.cutoffCircle_range_le_square_range

#print axioms PaperN.PartII.selectedEigenspaces_le_square_range
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffCircle_range_proved

#print axioms PaperN.PartII.horizontal_segment_integral
#print axioms PaperN.PartII.vertical_segment_integral
#print axioms PaperN.PartII.rectangleResolvent_eq_zero_of_closed_rectangle

#print axioms PaperN.PartII.boxResolvent_eq_boundary
#print axioms PaperN.PartII.boxResolvent_eq_zero_of_closed_box
#print axioms PaperN.PartII.boxResolvent_eq_zero_of_im_interval
#print axioms PaperN.PartII.boxResolvent_split_vertical
#print axioms PaperN.PartII.vertical_resolvent_intervalIntegrable
#print axioms PaperN.PartII.rectangleResolvent_height_independent

#print axioms PaperN.PartII.horizontal_resolvent_intervalIntegrable
#print axioms PaperN.PartII.rectangleResolvent_split_horizontal
#print axioms PaperN.PartII.rectangleResolvent_eq_zero_of_real_interval
#print axioms PaperN.PartII.rectangleResolvent_move_left
#print axioms PaperN.PartII.rectangleResolvent_move_right
#print axioms PaperN.PartII.rectangleResolvent_deformation

#print axioms PaperN.PartII.scalarRectangle_outside
#print axioms PaperN.PartII.scalarRectangle_real_outside
#print axioms PaperN.PartII.rectangleResolvent_kills_outside_eigenvector
#print axioms PaperN.PartII.rectangleEigenCondition_of_mem_spectrum
#print axioms PaperN.PartII.rectangleResolvent_apply_outside

#print axioms PaperN.PartII.scalarSegment_eq_rotated_log
#print axioms PaperN.PartII.scalarRectangle_real_inside
#print axioms PaperN.PartII.rectangleResolvent_apply_inside

#print axioms PaperN.PartII.rectangleResolvent_apply_eigenvector_ite
#print axioms PaperN.PartII.rectangleResolvent_eq_starProjection
#print axioms PaperN.PartII.circleResolvent_realInterval_apply_eigenvector
#print axioms PaperN.PartII.rectangleResolvent_eq_circle_of_compact_symmetric

#print axioms PaperN.PartII.resolvent_apply_eq_second_order
#print axioms PaperN.PartII.segment_inverse_square_integral
#print axioms PaperN.PartII.quadrilateral_inverse_square_integral

#print axioms PaperN.PartII.segmentResolvent_second_order
#print axioms PaperN.PartII.quadrilateralResolvent_second_order
#print axioms PaperN.PartII.quadrilateralResolvent_square_factor
#print axioms PaperN.PartII.rectangle_zero_edge_condition
#print axioms PaperN.PartII.rectangleResolvent_range_le_square_range

#print axioms PaperN.PartII.AmbientKernel.ambient_rectangle_eq_circle_proved
#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffContour_eq_circle_proved

#print axioms PaperN.PartII.AmbientKernel.ambient_cutoffContour_eq_circle_of_bound

#print axioms PaperN.PartII.IsAbsoluteNeighborhoodRetract.extension_of_factor
#print axioms PaperN.PartII.IsAbsoluteNeighborhoodRetract.isAbsoluteNeighborhoodExtensor_of_separable

#print axioms PaperN.PartI.CompactCoupling.glue_commute
#print axioms PaperN.PartI.CompactCoupling.cost_trans_le
#print axioms PaperN.PartI.ghpEDist_triangle
#print axioms PaperN.PartI.ghpDist_triangle
#print axioms PaperN.PartI.MeasuredGHSpace.distance_triangle

#print axioms PaperN.PartI.ghpMetricInput_of_separation
#print axioms PaperN.PartI.ghpMetricInput_iff_separation
#print axioms PaperN.PartI.ghpMetricInput_of_separation_dist
#print axioms PaperN.PartI.MeasuredGHSpace.pseudoMetricSpace
#print axioms PaperN.PartI.GHPMetricInput.toPseudoMetricSpace_eq

#print axioms PaperN.PartI.CompactCoupling.isomorphic_of_cost_eq_zero
#print axioms PaperN.PartI.isometryEquiv_of_ghpDist_eq_zero

#print axioms PaperN.PartI.exists_coupling_cost_lt_of_ghpDist_eq_zero
#print axioms PaperN.PartI.exists_couplings_tendsto_zero_of_ghpDist_eq_zero

#print axioms PaperN.PartI.BasedAmbient.couplingJointMap_left
#print axioms PaperN.PartI.BasedAmbient.couplingJoint_hausdorffEDist
#print axioms PaperN.PartI.BasedAmbient.couplingJoint_levyProkhorovEDist
#print axioms PaperN.PartI.zero_ghp_common_ambient

#print axioms PaperN.PartI.compactRealization_of_common_ambient
#print axioms PaperN.PartI.zero_ghp_compact_common_realization

#print axioms PaperN.PartI.isCompact_isometry_embeddings
#print axioms PaperN.PartI.isometry_embeddings_subsequence

#print axioms PaperN.PartI.hausdorffDist_range_tendsto_of_uniform
#print axioms PaperN.PartI.prokhorov_map_tendsto_of_uniform
#print axioms PaperN.PartI.isomorphic_of_ghpDist_eq_zero
#print axioms PaperN.PartI.ghpSeparation_proved
#print axioms PaperN.PartI.ghpMetricInput_proved

#print axioms PaperN.PartI.exists_coupling_cost_lt
#print axioms PaperN.PartI.exists_couplings_cost_tendsto
#print axioms PaperN.PartI.ghpCommonEmbeddingInput_proved

#print axioms PaperN.PartI.measuredForget_lipschitz
#print axioms PaperN.PartI.ghpCauchy_common_underlying
#print axioms PaperN.PartI.ghp_completeSpace

#print axioms PaperN.PartI.exists_probabilities_ghp_tendsto
#print axioms PaperN.PartI.denseRange_probabilityClasses
#print axioms PaperN.PartI.ghp_separableSpace
#print axioms PaperN.PartI.ghpPolishInput_proved

#print axioms PaperN.PartII.localModel_main
#print axioms PaperN.PartII.ghSpace_absoluteRetract_main

#print axioms PaperN.PartII.localModel_concrete_main

#print axioms PaperN.PartII.LocalModel.errorMap
#print axioms PaperN.PartII.LocalModel.errorMap_center_lt

#print axioms PaperN.PartIV.discreteApproximation_main
#print axioms PaperN.PartIV.hilbertCubeDiscreteApproximation_main
