import PaperN.PartIV.MainTheorem

#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert_from_selection_inputs

#print axioms PaperN.PartIV.ghSpace_homeomorphic_hilbert_main
