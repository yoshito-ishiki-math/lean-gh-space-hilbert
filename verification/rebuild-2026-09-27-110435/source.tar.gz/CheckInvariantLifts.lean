import PaperN.PartI.InvariantSelection

#print PaperN.PartI.GHCommonEmbeddingInput
#print PaperN.PartI.ProbabilityApproximationInput
#print PaperN.PartI.CommonRealization.HaarConvergenceStatement
#print PaperN.PartI.CommonRealization.InvariantApproximationStatement
#print PaperN.PartI.InvariantLiftsStatement
#print PaperN.PartI.OpenInvariantProjectionStatement
#print PaperN.PartI.InvariantValovInput
#print PaperN.PartI.InvariantFiberLawSelectionStatement
#check @PaperN.PartI.invariantLifts_spec
#check @PaperN.PartI.openInvariantProjection_spec
#check @PaperN.PartI.invariantFiberLawSelection_spec
#print axioms PaperN.PartI.integral_haarAverage
#print axioms PaperN.PartI.CommonRealization.integral_averagedProbability
#print axioms PaperN.PartI.CommonRealization.haarConvergence_spec
#print axioms PaperN.PartI.CommonRealization.ghpDist_le_max
#print axioms PaperN.PartI.CommonRealization.ghpDist_tendsto
#print axioms PaperN.PartI.probabilityMixture_fullSupport
#print axioms PaperN.PartI.integral_probabilityMixture
#print axioms PaperN.PartI.norm_integral_probabilityMixture_sub_le
#print axioms PaperN.PartI.CommonRealization.mixture_weakConverges
#print axioms PaperN.PartI.CommonRealization.invariantApproximation_spec
#print axioms PaperN.PartI.invariantLifts_spec
#print axioms PaperN.PartI.isOpenMap_of_sequence_lifts
#print axioms PaperN.PartI.invariantProjection_sequenceLift
#print axioms PaperN.PartI.openInvariantProjection_spec
#print axioms PaperN.PartI.invariantFiberLawSelection_spec
-- No assumed metric or new cited-input instance is silently installed.
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
