import PaperN.PartIV.MainTheorem
open PaperN.PartI PaperN.PartII PaperN.PartIV
set_option pp.universes true
#print PaperN.PartI.GHPMetricInput
#print PaperN.PartI.GHPPolishInput
#print PaperN.PartI.GHPCommonEmbeddingInput
#print PaperN.PartI.GHCommonEmbeddingInput
#print PaperN.PartI.ProbabilityApproximationInput
#print PaperN.PartI.InvariantValovInput
#print PaperN.PartII.DistanceKernelSpectralInput
#print PaperN.PartII.CutoffProjectionConvergenceInput
#print PaperN.PartII.CollectivelyCompactSpectralInclusionInput
#print PaperN.PartII.CompactEigenvalueFinitenessInput
#print PaperN.PartII.CompactCutoffRieszRangeInput
#print PaperN.PartII.RectangleCircleResolventInput
#print PaperN.PartII.EquivariantHyperspaceARInput
#print PaperN.PartII.OrbitARInput
#print PaperN.PartII.HannerDominationInput
#print PaperN.PartII.HannerANRCategoryInput
#print PaperN.PartII.ANRToANEInput
#print PaperN.PartII.ContractibleANEToAEInput
#print PaperN.PartIV.TorunczykRecognitionInput
