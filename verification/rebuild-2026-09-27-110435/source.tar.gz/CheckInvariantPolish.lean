import PaperN.PartI.InvariantPolish
import PaperN.PartI.UniformOrbit

#print PaperN.PartI.InvariantMeasuredPolishStatement
#print PaperN.PartI.CommonRealization.UniformOrbitIntegralsStatement
#check @PaperN.PartI.invariantMeasuredPolish_spec
#check @PaperN.PartI.CommonRealization.uniformOrbitIntegrals_spec
#print axioms PaperN.PartI.polishSpace_of_isGDelta
#print axioms PaperN.PartI.invariantMeasuredPolish_spec
#print axioms PaperN.PartI.CommonRealization.integral_orbitProbabilityAt
#print axioms PaperN.PartI.CommonRealization.limitActionProbability_eq
#print axioms PaperN.PartI.CommonRealization.eventually_orbitError_lt
#print axioms PaperN.PartI.CommonRealization.uniformOrbitIntegrals_spec
