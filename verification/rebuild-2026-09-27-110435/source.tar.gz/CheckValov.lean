import PaperN.PartI.Valov
import PaperN.PartI.FixedLawAverage

#print PaperN.PartI.ValovProbabilityInput
#print PaperN.PartI.ValovSelectionStatement
#print PaperN.PartI.FiberLawSelectionStatement
#print PaperN.PartI.FixedFullSupportGDeltaStatement
#print PaperN.PartI.FixedInvariantClosedStatement
#print PaperN.PartI.FixedInvariantFullSupportGDeltaStatement
#print PaperN.PartI.FixedLawAverageStatement
#check @PaperN.PartI.probability_innerRegular_polish
#check @PaperN.PartI.valovSelection_spec
#check @PaperN.PartI.fiberLawSelection_spec
#check @PaperN.PartI.fixedFullSupportGDelta_spec
#check @PaperN.PartI.fixedInvariantClosed_spec
#check @PaperN.PartI.fixedInvariantFullSupportGDelta_spec
#check @PaperN.PartI.fixedLawAverage_spec
#print axioms PaperN.PartI.probabilityPushforward
#print axioms PaperN.PartI.probability_innerRegular_polish
#print axioms PaperN.PartI.valovSelection_spec
#print axioms PaperN.PartI.measure_fiber_of_pushforward_eq_dirac
#print axioms PaperN.PartI.support_subset_fiber_of_pushforward_eq_dirac
#print axioms PaperN.PartI.fiberLawSelection_spec
#print axioms PaperN.PartI.isOpen_probability_positive
#print axioms PaperN.PartI.support_eq_univ_iff_basis_positive
#print axioms PaperN.PartI.fixedFullSupportGDelta_spec
#print axioms PaperN.PartI.fixedInvariantClosed_spec
#print axioms PaperN.PartI.fixedInvariantFullSupportGDelta_spec
#print axioms PaperN.PartI.measurableSet_fixedInvariantFullSupport
#print axioms PaperN.PartI.fixedLawAverage_spec
