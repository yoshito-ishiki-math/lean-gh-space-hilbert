import PaperN.PartI.VaryingFiberTransport

#print PaperN.PartI.LimitSupportStatement
#print PaperN.PartI.VaryingFiberTransportStatement
#check @PaperN.PartI.varying_fiberProbability_integral_tendsto
#print axioms PaperN.PartI.limitSupport_spec
#print axioms PaperN.PartI.varying_fiberProbability_tendsto
#print axioms PaperN.PartI.varyingFiberTransport_spec
#print axioms PaperN.PartI.varying_fiberProbability_integral_tendsto
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
