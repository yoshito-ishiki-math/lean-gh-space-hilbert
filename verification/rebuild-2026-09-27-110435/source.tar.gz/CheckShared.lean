import PaperN

#print PaperN.Shared.CorrespondenceEmbeddingSupStatement
#print PaperN.Shared.UniformSeparatedStatement
#print PaperN.Shared.PseudometricComparisonStatement
#print PaperN.Shared.ScalingStatement
#print PaperN.Shared.ContractionStatement

#print axioms PaperN.Shared.ContinuousPseudometric.proj_surjective
#print axioms PaperN.Shared.ContinuousPseudometric.dist_proj
#print axioms PaperN.Shared.ContinuousPseudometric.proj_eq_iff
#print axioms PaperN.Shared.ContinuousPseudometric.continuous_proj
#print axioms PaperN.Shared.ContinuousPseudometric.nonneg
#print axioms PaperN.Shared.scaledGH_congr
#print axioms PaperN.Shared.scaleGH_toGHSpace
#print axioms PaperN.Shared.scaledGH_one
#print axioms PaperN.Shared.scaledGH_zero
#print axioms PaperN.Shared.scaleGH_one
#print axioms PaperN.Shared.scaleGH_zero
#print axioms PaperN.Shared.scaleGH_point
#print axioms PaperN.Shared.scaleGH_dist_le
#print axioms PaperN.Shared.continuous_scaleGH
#print axioms PaperN.Shared.continuous_contraction
#print axioms PaperN.Shared.contraction_zero
#print axioms PaperN.Shared.contraction_one
#print axioms PaperN.Shared.contraction_point
#print axioms PaperN.Shared.ghSpace_contractible
#print axioms PaperN.Shared.scaling_spec
#print axioms PaperN.Shared.contraction_toGHSpace
#print axioms PaperN.Shared.contraction_spec
#print axioms PaperN.Shared.distortionLE_iff
#print axioms PaperN.Shared.correspondenceEmbedding_sup_spec
#print axioms PaperN.Shared.correspondenceEmbedding_spec
#print axioms PaperN.Shared.ghDist_le_half_distortion
#print axioms PaperN.Shared.error_bdd
#print axioms PaperN.Shared.le_error
#print axioms PaperN.Shared.error_nonneg
#print axioms PaperN.Shared.quotient_ghDist_le
#print axioms PaperN.Shared.quotient_ghDist_le_norm
#print axioms PaperN.Shared.uniform_norm_comparison
#print axioms PaperN.Shared.error_blend_le
#print axioms PaperN.Shared.pseudometricComparison_spec
#print axioms PaperN.Shared.exists_correspondence_distortion
#print axioms PaperN.Shared.scaledGH_dist_le
#print axioms PaperN.Shared.compact_uniform_separated_bound
#print axioms PaperN.Shared.uniformSeparated_spec

#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
