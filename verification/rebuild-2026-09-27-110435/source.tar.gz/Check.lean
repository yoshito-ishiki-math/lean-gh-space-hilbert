import PaperN

-- Environment checks only, not manuscript proofs.
example : CompleteSpace PaperN.GH := inferInstance
example : SecondCountableTopology PaperN.GH := inferInstance
example : Nonempty PaperN.GH := inferInstance
example : CompleteSpace PaperN.RealHilbert := inferInstance

#check PaperN.HilbertHomeomorphismGoal
#check PaperN.DiscreteApproximationGoal
#print axioms PaperN.HilbertHomeomorphismGoal
#print axioms PaperN.DiscreteApproximationGoal
