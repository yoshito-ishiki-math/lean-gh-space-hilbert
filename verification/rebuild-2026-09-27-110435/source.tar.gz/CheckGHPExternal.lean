import PaperN.PartI.GHPExternal

#print PaperN.PartI.GHPMetricInput
#print PaperN.PartI.GHPPolishInput
#print PaperN.PartI.GHPCommonEmbeddingInput
#print PaperN.PartI.CommonRealization
#print PaperN.PartI.CommonMeasuredEmbeddingStatement
#print PaperN.PartI.GHPPolishStatement
#print PaperN.PartI.GHPForgetLipschitzStatement
#print PaperN.PartI.InvariantProjectionContinuousSurjectiveStatement
#check @PaperN.PartI.ghpPolish_spec
#check @PaperN.PartI.ghpForgetLipschitz_spec
#check @PaperN.PartI.invariantProjectionContinuousSurjective_spec
#check @PaperN.PartI.commonMeasuredEmbedding_spec
#check @PaperN.PartI.commonMeasuredEmbedding_of_tendsto
#print axioms PaperN.PartI.GHPMetricInput.metricSpace
#print axioms PaperN.PartI.ghpPolish_spec
#print axioms PaperN.PartI.ghpForgetLipschitz_spec
#print axioms PaperN.PartI.invariantProjectionContinuousSurjective_spec
#print axioms PaperN.PartI.commonMeasuredEmbedding_spec
#print axioms PaperN.PartI.commonMeasuredEmbedding_of_tendsto
-- Importing this module must not silently install an assumed GHP metric.
#check_failure (inferInstance : MetricSpace PaperN.PartI.MeasuredGHSpace)
