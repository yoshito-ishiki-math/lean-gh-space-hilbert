import PaperN.PartIV.MainTheorem
import PaperN.PartI.CurrentStatements

set_option pp.universes true
#check PaperN.PartI.currentInvariantAssignment_spec
#check PaperN.PartII.LocalModel
#check PaperN.PartII.LocalModel.pseudometric_invariant
#check PaperN.PartII.NormedCoordinatePair.pseudometric
#check PaperN.PartII.AmbientKernel.exists_localModel
#check PaperN.PartII.AmbientKernel.exists_AR_domination
#check PaperN.PartII.AmbientKernel.ghSpace_absoluteNeighborhoodRetract
#check PaperN.PartII.AmbientKernel.ghSpace_absoluteRetract
#check PaperN.PartIV.ghSpace_homeomorphic_hilbert_main

#check PaperN.PartI.currentInvariantAssignment_main
#check PaperN.PartII.localModel_main
#check PaperN.PartII.ghSpace_absoluteRetract_main

#check PaperN.PartII.localModel_concrete_main
#check PaperN.PartII.LocalModel.universal_representatives_converge

#check PaperN.PartIV.discreteApproximation_main
#check PaperN.PartIV.hilbertCubeDiscreteApproximation_main
